export interface UserProfile {
  name: string;
  age: number;
  cigarettesPerDay: number;
  pricePerPack: number;
  startDate: string; // ISO string
}

export interface DailyRemedy {
  title: string;
  description: string;
  recipe: string[];
}

export interface MindBodyFocusTask {
  type: 'Mindset' | 'Physical' | 'Action' | 'All Day' | 'Morning' | 'Evening' | 'Practice' | 'Flexible' | 'During drive' | 'After meals';
  description: string;
}

export interface MindBodyFocus {
  title: string;
  tasks: MindBodyFocusTask[];
}

export interface DayPlan {
  day: number;
  title: string;
  theme: string;
  remedy: DailyRemedy;
  mindBodyFocus: MindBodyFocus;
  medicalGuidance: string;
  cravingBuster: {
    title: string;
    description: string;
  };
  financialWin: string;
  healthFact: string;
  checklist: { id: string; label: string }[];
  image: { id: string };
}
