
import type { DayPlan } from './types';

export const daysData: DayPlan[] = [
  {
    day: 1,
    title: 'Commit & Map Your "Why"',
    theme:
      "Today is Day Zero for your new life. It's about making a firm commitment and understanding the deep, personal reasons that will fuel your journey. This is your foundation.",
    remedy: {
      title: 'Citrus-Mint Water',
      description:
        "Quitting can cause dry mouth, and cravings can be mistaken for thirst. This refreshing water tackles both. The citrus and mint provide a crisp flavor that helps reset your palate and fight the urge for a cigarette's taste. Constant hydration helps flush out nicotine and other toxins faster.",
      recipe: [
        'Get a large (2-liter) pitcher.',
        'Add 1 sliced lemon, 1 sliced lime, and about 10-15 fresh mint leaves.',
        'Fill with cold water and let it infuse for at least an hour.',
        'Sip constantly throughout the day.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'The "Why" List. Write down at least 10 powerful, personal reasons you are quitting. Be specific: "To run with my kids without getting tired," "To save $300 a month for a vacation." This list is your anchor.',
        },
        {
          type: 'Physical',
          description:
            'The Foundation Walk. Go for a gentle 10-15 minute walk. Focus on your breathing: inhale for 4 seconds, exhale for 6 seconds. This is about movement, not speed.',
        },
      ],
    },
    medicalGuidance:
      "Your focus is on preparation. Schedule an appointment with your doctor or a pharmacist to discuss your quit plan and learn about Nicotine Replacement Therapy (NRT) like patches, gum, or lozenges, and prescription medications like Varenicline or Bupropion.",
    cravingBuster: {
      title: "Your Craving-Buster Strategy: The 4 D's",
      description:
        "An urge feels intense, but it will pass. Act immediately: Delay for 10 minutes. Deep Breathe (inhale 4s, hold 4s, exhale 6s). Drink Water from your pitcher. Do Something Else: get up and move.",
    },
    financialWin:
      'Your projected yearly savings is the vacation, down payment, or debt-free future you\'re working towards. Take a screenshot. This is your financial "Why."',
    healthFact:
      'The benefits start immediately. Within 20 minutes of your last cigarette, your heart rate and blood pressure begin to drop back to normal levels.',
    checklist: [
      { id: 'day1-remedy', label: 'Prepare and drink Citrus-Mint Water' },
      { id: 'day1-mindset', label: 'Create my "Why" List' },
      { id: 'day1-exercise', label: 'Complete the Foundation Walk' },
      { id: 'day1-craving', label: 'Practice the 4 D\'s' },
    ],
    image: { id: 'day1' },
  },
  {
    day: 2,
    title: 'Tell Your Team & Recruit Support',
    theme: 'You are not alone. Quitting is easier with a support system. Today is about building your team and letting them know how they can help.',
    remedy: {
      title: 'Peppermint Tea',
      description:
        'Many smokers have a ritual of a cigarette after meals. Replacing this with warm, soothing peppermint tea creates a new, healthier ritual. Its strong, clean flavor is a great palate cleanser.',
      recipe: [
        'Use 1 peppermint tea bag or 1 tablespoon of fresh peppermint leaves.',
        'Pour 8 ounces of boiling water over the tea.',
        'Steep for 5 minutes, then drink it mindfully after your meals today.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (10 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Assemble Your Support Crew. Identify at least two supporters. Text them: "I\'m on Day 2 of quitting and need your support. Can you check in with me tomorrow?"',
        },
        {
          type: 'Action',
          description:
            'Create a "Lifeline" List. In your phone, create a "Quit Support" group with your supporters\' numbers and a national quit-line number (e.g., 1-800-QUIT-NOW in the US).',
        },
      ],
    },
    medicalGuidance:
      "If you saw a doctor yesterday, review the plan. If you haven't spoken to a professional yet, make that call today.",
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Phone a Friend',
      description:
        'When you feel an urge, open your "Quit Support" list and call or text someone. Saying "I\'m having a tough craving" out loud can cut its power in half.',
    },
    financialWin:
      "Today's savings from not smoking could buy a high-quality box of peppermint tea. You're replacing a costly, harmful habit with an inexpensive, healthy one.",
    healthFact:
      'Within 12 hours of quitting, the carbon monoxide level in your blood drops to normal, allowing more oxygen to reach your heart and other organs.',
    checklist: [
      { id: 'day2-remedy', label: 'Replace after-meal cigarette with Peppermint Tea' },
      { id: 'day2-mindset', label: 'Text my support crew' },
      { id: 'day2-action', label: 'Create my "Lifeline" list' },
    ],
    image: { id: 'day2' },
  },
  {
    day: 3,
    title: 'Medication Plan & Beating Constipation',
    theme:
      'Knowledge is power. Using approved medications can double your chances of quitting. We\'ll also tackle a common physical side effect.',
    remedy: {
      title: 'Oat-Banana Smoothie',
      description:
        "Nicotine affects digestion. Quitting often causes constipation. This smoothie is packed with fiber from oats and bananas to help keep things moving, and it provides steady energy.",
      recipe: [
        'Combine: 1 ripe banana, 1/4 cup rolled oats, 1/2 cup milk (or yogurt/plant-based milk), 1/2 cup water, and a dash of cinnamon.',
        'Blend for 60 seconds until completely smooth.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (20 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Educate Yourself. Spend 10 minutes reading about NRT (patch, gum) and non-nicotine pills (Varenicline/Bupropion). Understand how they work.',
        },
        {
          type: 'Action',
          description:
            "Make the Call. Finalize your decision with a doctor or pharmacist. Get the prescription filled or buy the NRT product today.",
        },
      ],
    },
    medicalGuidance:
      'Experts often recommend Combination Therapy: the patch (for long-term control) plus gum or a lozenge (for breakthrough cravings). Follow directions carefully.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Active Replacement',
      description:
        'Practice your plan for an intense craving. If using NRT gum/lozenge, reach for it immediately. If not, take a brisk 3-minute walk up and down stairs.',
    },
    financialWin:
      'A one-month supply of NRT might seem expensive, but it\'s almost always cheaper than a month\'s worth of cigarettes.',
    healthFact: 'Within 24 hours, your risk of a heart attack begins to decrease significantly.',
    checklist: [
      { id: 'day3-remedy', label: 'Make an Oat-Banana Smoothie' },
      { id: 'day3-mindset', label: 'Educate myself on quit-aids' },
      { id: 'day3-action', label: 'Finalize my medication plan' },
    ],
    image: { id: 'day3' },
  },
  {
    day: 4,
    title: 'Identify Your Triggers',
    theme: 'Smoking is a habit built on triggers. Today, we become detectives. By identifying your triggers, you can create a plan to disarm them.',
    remedy: {
      title: 'Ginger-Lemon Tea',
      description:
        "This warm, decaffeinated drink is a perfect replacement for a 'stress cigarette.' Ginger calms an anxious stomach, while lemon provides a fresh, clean taste.",
      recipe: [
        'Place 3-4 thin slices of fresh ginger and a thick slice of lemon in a mug.',
        'Pour 8-10 ounces of boiling water over them.',
        'Let steep for 5 minutes before drinking.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description: 'Trigger Mapping. Create a list of your top 5-10 smoking triggers (e.g., morning coffee, stress, driving). Be honest.',
        },
        {
          type: 'Action',
          description:
            'Plan Your Defense. Next to each trigger, write down one replacement action (e.g., "Trigger: Stress -> Replacement: Drink ginger-lemon tea & deep breathe").',
        },
      ],
    },
    medicalGuidance:
      'Pay close attention to when your triggers hit. This is the perfect time to use your short-acting NRT (gum/lozenge) proactively, 5-10 minutes *before* an expected trigger.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Pattern Interrupt',
      description:
        "Don't just fight the urge—change the pattern. If you always smoke on your balcony, go to the living room instead. Use the self-coaching line: 'I am learning to live without smoking.'",
    },
    financialWin:
      'Think about a trigger, like the coffee shop where you\'d buy a pack. Today, you just bought the coffee. The savings from that one trigger add up to hundreds or thousands over a year.',
    healthFact:
      'At 48 hours, nerve endings start to regrow. Your sense of smell and taste are improving. Notice how your food and tea taste more vibrant!',
    checklist: [
      { id: 'day4-remedy', label: 'Drink Ginger-Lemon Tea during a pause' },
      { id: 'day4-mindset', label: 'Map my smoking triggers' },
      { id: 'day4-action', label: 'Create a replacement action for each trigger' },
    ],
    image: { id: 'day4' },
  },
  {
    day: 5,
    title: 'Clear Your Environment',
    theme: "Your environment can be your biggest ally or worst enemy. Today, we create a 'smoke-free sanctuary' where it's easy to make the right choice.",
    remedy: {
      title: 'Green Power Smoothie',
      description:
        'As your senses return, appreciate fresh flavors. This smoothie is packed with nutrients, provides natural energy, and the fresh taste reinforces your new, clean lifestyle.',
      recipe: ['Blend a large handful of spinach, 1 cup of frozen pineapple or mango, and 1 cup of water or coconut water until smooth.'],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (30 minutes)',
      tasks: [
        {
          type: 'Action',
          description:
            'The Great Purge. Gather ALL cigarettes, lighters, and ashtrays from your home, car, and work. Put them in a bag and dispose of them outside your home. Then, wash all clothes, coats, and bedding to remove the smoke smell.',
        },
      ],
    },
    medicalGuidance:
      "Keep your quit-aids visible and accessible. Put NRT gum where cigarettes used to be. Make your medicine the new, easy-to-reach habit.",
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Change Your Location',
      description:
        'If a craving hits in a place you used to smoke (e.g., your favorite chair), get up and leave the room. Go outside for a minute of fresh air. Avoid alcohol, a major relapse trigger.',
    },
    financialWin: 'Put the money you would have spent on a pack today into a clear jar. Watching the cash grow is a powerful visual motivator.',
    healthFact:
      'At 72 hours (3 days), nicotine is completely out of your body. Withdrawal might peak now. Know that it gets easier from here. Breathing also becomes easier as bronchial tubes relax.',
    checklist: [
      { id: 'day5-remedy', label: 'Enjoy a Green Power Smoothie' },
      { id: 'day5-action-home', label: 'Purge all smoking items from home' },
      { id: 'day5-action-car', label: 'Clean out my car' },
      { id: 'day5-action-wash', label: 'Wash clothes and bedding' },
    ],
    image: { id: 'day5' },
  },
  {
    day: 6,
    title: 'Rehearse Your Quit Day',
    theme:
      "Tomorrow is the big day. The best way to ensure success is to practice. Today is a dress rehearsal for your new smoke-free morning routine.",
    remedy: {
      title: 'Warm Milk with Honey',
      description:
        "A good night's sleep is crucial. Anxiety can be high tonight. Warm milk contains tryptophan, which can help promote sleep. It's a calming, caffeine-free ritual.",
      recipe: [
        'Gently warm one cup (8 ounces) of milk (or a plant-based alternative) in a saucepan. Do not boil.',
        'Stir in 1 teaspoon of honey until dissolved.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Practice',
          description:
            'The Practice Run. Go through your plan for tomorrow morning. If you normally smoke with coffee on the porch, drink your coffee in the kitchen instead. Visualize a successful, smoke-free day.',
        },
        {
          type: 'Physical',
          description:
            'Calming Stretches. Before bed, do 10 minutes of gentle stretching. Try neck rolls (5 each side), shoulder shrugs (10 reps), and a gentle torso twist (5 each side). Combine this with deep breathing to release tension.',
        },
      ],
    },
    medicalGuidance:
      'Have your medication ready for tomorrow. If using the patch, have it on your bedside table to put on the moment you wake up. Have gum or lozenges with you.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Positive Self-Talk',
      description:
        'Fight back against negative thoughts ("I can\'t do this"). Write on a sticky note: "Urges are temporary. They cannot hurt me." Repeat this to yourself.',
    },
    financialWin: 'Pre-calculate how much money you will have saved by the end of Day 7. Plan a small, healthy treat you will buy yourself with it.',
    healthFact: 'This is your last day as a smoker. Within 2 weeks to 3 months of quitting, your lung function can increase by up to 30%. That journey starts tomorrow.',
    checklist: [
      { id: 'day6-remedy', label: 'Drink Warm Milk with Honey before bed' },
      { id: 'day6-practice', label: 'Mentally rehearse my quit day' },
      { id: 'day6-physical', label: 'Do calming stretches' },
      { id: 'day6-prepare', label: 'Get my medications ready for tomorrow' },
    ],
    image: { id: 'day6' },
  },
  {
    day: 7,
    title: 'QUIT DAY!',
    theme: "This is it. The first day of your smoke-free life. Your only job today is to get through the day without smoking. Be kind to yourself and stay busy.",
    remedy: {
      title: 'Orange-Carrot-Ginger Juice',
      description:
        'Celebrate your returning sense of taste! This vibrant juice is packed with Vitamin C, which smoking depletes. It also helps keep blood sugar stable, preventing irritability.',
      recipe: [
        'If you have a juicer, juice 2 large carrots, 1 peeled orange, and a 1-inch knob of ginger.',
        'If not, eat a whole orange and drink a large glass of water.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (All Day)',
      tasks: [
        {
          type: 'Morning',
          description: 'As soon as you wake up, put on your nicotine patch (if using). Go for a brisk 10-minute walk. Text your support crew: "Today is my Quit Day!"',
        },
        {
          type: 'All Day',
          description:
            'Stay Busy! Plan your day to avoid downtime. Run errands, organize a closet, watch a movie, meet a non-smoking friend for a walk.',
        },
        {
          type: 'Evening',
          description: 'Celebrate! You made it through Day 1. Take a relaxing bath, watch your favorite comedy, or enjoy a delicious meal. You earned it.',
        },
      ],
    },
    medicalGuidance:
      "Today is when your medication plan is most critical. Use your patch, and use short-acting NRT (gum/lozenge) for any breakthrough urges. Don't try to 'tough it out.'",
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Emergency Protocol',
      description:
        "When a craving hits: 1. Use the 4 D's. 2. Use your short-acting NRT. 3. Call or text someone from your 'Quit Support' list. 4. Read your 'Why' list from Day 1.",
    },
    financialWin: 'You did it! You have officially saved the cost of one full day\'s worth of cigarettes. Put that physical cash in your savings jar.',
    healthFact:
      'Today, your body is 100% free of new toxins from cigarettes. Your oxygen levels are rising, giving more life to every cell in your body.',
    checklist: [
      { id: 'day7-start', label: 'Start my day with my Quit Day plan' },
      { id: 'day7-busy', label: 'Stay busy all day' },
      { id: 'day7-meds', label: 'Use my medications as directed' },
      { id: 'day7-celebrate', label: 'Celebrate making it through Day 1' },
    ],
    image: { id: 'day7' },
  },
  {
    day: 8,
    title: 'Normalize Withdrawal & Protect Your Energy',
    theme:
      'Nicotine has left your body, and now your system is learning to function without it. Fatigue, irritability, and "brain fog" are normal. Be gentle with yourself.',
    remedy: {
      title: 'The Fiber & Hydration Duo',
      description: 'Your body is adjusting. The solution is simple: fiber and water. Keep your Citrus-Mint water full and add fiber-rich foods (apples, pears, spinach, carrots) to every meal.',
      recipe: [
        'Keep sipping water all day long (aim for 2 liters).',
        'Add a pear or an apple (skin on) to your breakfast.',
        'Have a side salad with spinach for lunch.',
        'Snack on 1 cup of raw carrots or celery sticks.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (Flexible)',
      tasks: [
        {
          type: 'Physical',
          description:
            'The Energy Boost Walk. Instead of one long walk, take 2-3 short, 5-10 minute walks throughout the day, especially when you feel tired. This is more effective for boosting energy than one long session.',
        },
        {
          type: 'Mindset',
          description:
            'Strategic Scheduling. Withdrawal saps energy. Identify your most demanding task for the day and schedule it for when you typically have the most energy. Give yourself permission to rest or do something easy during low-energy periods.',
        },
      ],
    },
    medicalGuidance:
      'Withdrawal symptoms peak in the first 1-2 weeks. This is when your NRT is working its hardest. Do not stop using it. If cravings are very strong, speak to your pharmacist or doctor.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Reframe the Feeling',
      description:
        'When a wave of irritability hits, say to yourself: "This feeling is a sign my body is healing. It\'s temporary and it will pass." This reframes the negative into a positive.',
    },
    financialWin: 'Check your savings. You\'ve officially saved enough for a nice lunch out, a new book, or a premium movie rental. Turn a draining expense into a reward.',
    healthFact:
      'The "smoker\'s cough" can get temporarily worse. Don\'t be alarmed! This is a positive sign. The cilia in your lungs are regrowing and cleaning out tar and debris.',
    checklist: [
      { id: 'day8-hydrate', label: 'Stay hydrated and eat fiber-rich foods' },
      { id: 'day8-walk', label: 'Take short "Energy Boost" walks' },
      { id: 'day8-schedule', label: 'Schedule my day strategically' },
      { id: 'day8-reframe', label: 'Reframe a withdrawal symptom as a sign of healing' },
    ],
    image: { id: 'day8' },
  },
  {
    day: 9,
    title: 'Master Your Stress',
    theme: 'Many people smoke to deal with stress. Now, you need new, healthier tools for your stress-management toolbox.',
    remedy: {
      title: 'Rooibos "Tea Latte"',
      description:
        'Rooibos tea is naturally caffeine-free and has a calming effect. Making it into a latte creates a creamy, comforting drink that’s perfect for unwinding.',
      recipe: ['Brew 1 rooibos tea bag in 6 ounces of hot water for 5 minutes.', 'Pour into a large mug and top with 2-3 ounces of warm, frothed milk.', 'Add a tiny sprinkle of cinnamon.'],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Physical',
          description: 'Stress-Discharge Stretches. When you feel tense, release it with 10 minutes of light stretching. Perform 5 neck rolls each side, 10 shoulder shrugs, 10 arm circles forward and backward, and a 30-second quad stretch for each leg.',
        },
        {
          type: 'Mindset',
          description:
            'Create a "Calm" Playlist. Music directly affects mood. Create a 15-20 minute playlist of your favorite soft, relaxing music. This is your audio first-aid kit for stress.',
        },
      ],
    },
    medicalGuidance:
      "Stress is a major trigger. Ensure you're using your medication consistently to keep a baseline level of nicotine (if using NRT), as this will help you manage stress-induced cravings.",
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Move & Avoid',
      description:
        'Avoid Alcohol: Alcohol increases stress hormones and lowers resolve. Avoid it completely for the first month. Move Your Body: When stress hits, get up and do 20 jumping jacks or a 1-minute wall sit to discharge nervous energy.',
    },
    financialWin:
      "By drinking water or your rooibos tea and avoiding alcohol, you're saving your health, your willpower, AND your wallet.",
    healthFact:
      'Your blood circulation is improving. You might notice that your hands and feet are warmer, a direct result of better blood flow.',
    checklist: [
      { id: 'day9-remedy', label: 'Unwind with a Rooibos Tea Latte' },
      { id: 'day9-stretch', label: 'Do Stress-Discharge Stretches' },
      { id: 'day9-playlist', label: 'Create or listen to my "Calm" playlist' },
      { id: 'day9-avoid', label: 'Avoid alcohol today' },
    ],
    image: { id: 'day9' },
  },
  {
    day: 10,
    title: 'Think Like a Non-Smoker',
    theme:
      'A huge part of quitting is changing your identity from a "smoker who is trying to quit" to a "non-smoker." This shift starts in your mind.',
    remedy: {
      title: 'Cucumber-Lime Spritzer',
      description:
        "This is a sophisticated, refreshing drink that feels like a treat. It's hydrating and gives your hands something to hold, helping create the feeling of a new, clean identity.",
      recipe: [
        'In a tall glass, add 4-5 ribbons of cucumber (made with a vegetable peeler) and the juice of half a fresh lime.',
        'Add lots of ice and top with 8 ounces of sparkling water.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (10 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'The Power of Self-Coaching. Fight back against thoughts like "Just one won\'t hurt." Write three positive statements on sticky notes (e.g., "I am a non-smoker now.", "I choose health.", "This feeling will pass.") and put them where you\'ll see them.',
        },
      ],
    },
    medicalGuidance:
      'As you adopt a non-smoker identity, remember that using medication is a sign of strength, not weakness. It\'s a smart tool that successful non-smokers use.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Read, Reframe, React',
      description:
        'When a craving hits, read your nearest sticky note out loud. Then, immediately use the 4 D\'s. If it\'s part of your plan, use a piece of nicotine gum or a lozenge.',
    },
    financialWin:
      'By Day 10, if you were a pack-a-day smoker, you have likely saved close to $100 in many places. Start a list of what you could do with that money.',
    healthFact:
      'You\'re breathing easier because your lung capacity is improving. Try walking up a flight of stairs and notice the difference from 10 days ago.',
    checklist: [
      { id: 'day10-remedy', label: 'Make a Cucumber-Lime Spritzer' },
      { id: 'day10-mindset', label: 'Create and place positive self-talk notes' },
      { id: 'day10-craving', label: 'Practice the Read, Reframe, React strategy' },
    ],
    image: { id: 'day10' },
  },
  {
    day: 11,
    title: 'Celebrate and Socialize Safely',
    theme:
      "You've made it through the hardest part. It's time to celebrate, but also to learn how to navigate social situations as a non-smoker.",
    remedy: {
      title: 'Festive Berry-Lime Mocktail',
      description: 'A celebratory drink that\'s delicious, healthy, and keeps your hands busy in social settings. It looks and feels like a cocktail, without the alcohol.',
      recipe: [
        'In a shaker, muddle a handful of fresh raspberries.',
        'Add ice and the juice of one whole lime.',
        'Shake well and strain into a nice glass filled with ice.',
        'Top with sparkling water and garnish with a lime wedge.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Plan Your "No" Script. Rehearse saying "No, thanks, I don\'t smoke" or "I\'m not smoking anymore." Practice it in the mirror until it feels natural. A polite but firm "no" is all you need.',
        },
        {
          type: 'Physical',
          description:
            'The Social Stance. Practice standing confidently with your mocktail. Notice how it feels to have a drink in hand. This helps break the physical habit of holding a cigarette.',
        },

      ],
    },
    medicalGuidance:
      'Social events are high-risk. Before you go out, use your NRT (gum, lozenge, or inhaler) to manage cravings proactively. Have an "escape plan" if you feel overwhelmed.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Exit Plan',
      description:
        'If you feel a strong urge at a social event, politely excuse yourself and step outside for 5 minutes of fresh air and deep breathing. Your health comes first.',
    },
    financialWin:
      'The average price of a cocktail is more than a pack of cigarettes in many places. By choosing a mocktail or water, you are saving significantly.',
    healthFact:
      'Your energy levels are increasing. Your body is more efficient at using oxygen, making physical activity feel less strenuous.',
    checklist: [
      { id: 'day11-remedy', label: 'Make a celebratory mocktail' },
      { id: 'day11-mindset', label: 'Practice my "No, thanks" script' },
      { id: 'day11-physical', label: 'Practice the Social Stance' },
    ],
    image: { id: 'day11' },
  },
  {
    day: 12,
    title: 'Beat the Boredom',
    theme:
      'Now that the intense withdrawal is fading, a new enemy can emerge: boredom. We need to fill the time that smoking used to occupy.',
    remedy: {
      title: 'Crunchy Apple Slices with Nut Butter',
      description:
        'This snack satisfies multiple needs: the crunchiness mimics the hand-to-mouth action of smoking, the fiber keeps you full, and the protein from nut butter provides sustained energy.',
      recipe: [
        'Slice one apple (like a Fuji or Honeycrisp) into wedges.',
        'Serve with 2 tablespoons of your favorite nut butter (almond, peanut, cashew) for dipping.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (20 minutes)',
      tasks: [
        {
          type: 'Action',
          description:
            'The "Boredom Buster" List. Brainstorm a list of 10 quick (5-10 minute) activities you enjoy. Examples: listen to a new song, do a crossword puzzle, stretch, walk around the block, water plants.',
        },
        {
          type: 'Practice',
          description:
            'Pick one activity from your new list and do it today during a moment you might have previously smoked out of boredom.',
        },
      ],
    },
    medicalGuidance:
      'If you\'re feeling down or "blah," it could be a lingering effect of nicotine withdrawal on your brain chemistry. This is normal. Consistent use of your medication helps stabilize your mood.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Engage Your Brain',
      description: 'Cravings hate being ignored. Challenge your brain with a task that requires focus: a Sudoku puzzle, a language-learning app like Duolingo for 5 minutes, or organizing a drawer.',
    },
    financialWin:
      "Look at your savings jar or app. Could you buy a new book, a puzzle, or a small plant with the money you've saved? Invest in your new, healthier hobbies.",
    healthFact:
      'Your circulation continues to improve. This means more oxygen and nutrients are reaching your skin, leading to a healthier, more vibrant complexion over time.',
    checklist: [
      { id: 'day12-remedy', label: 'Eat apple slices and nut butter as a snack' },
      { id: 'day12-action', label: 'Create my "Boredom Buster" list' },
      { id: 'day12-practice', label: 'Try one new activity from my list' },
    ],
    image: { id: 'day12' },
  },
  {
    day: 13,
    title: 'Improve Your Sleep',
    theme:
      'Quitting can disrupt sleep patterns. Today, we focus on building a new evening routine that promotes deep, restorative rest.',
    remedy: {
      title: 'Calming Chamomile Tea',
      description: 'Chamomile is a well-known natural sedative. It helps calm the nervous system and prepare the body for sleep. It\'s a perfect replacement for a late-night cigarette.',
      recipe: [
        'Brew 1 chamomile tea bag in 8 ounces of hot water for 5-7 minutes.',
        'Drink it 30-60 minutes before you plan to go to bed.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (30 minutes before bed)',
      tasks: [
        {
          type: 'Evening',
          description:
            'The Digital Sunset. An hour before bed, turn off all screens (TV, phone, computer). The blue light disrupts sleep hormones. Read a physical book, listen to your "Calm" playlist, or take a warm bath instead.',
        },
        {
          type: 'Mindset',
          description:
            'Brain Dump. Keep a notepad by your bed. If your mind is racing, write down everything you\'re thinking about. This gets the worries out of your head and onto the page.',
        },
      ],
    },
    medicalGuidance:
      'Some quit-smoking medications can affect sleep. If you use the patch and have vivid dreams, try taking it off before bed (and putting a new one on in the morning). Talk to your pharmacist about this.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Evening Ritual',
      description:
        'If an evening craving hits, start your new wind-down routine immediately. Make your tea, turn on your playlist, and begin your digital sunset. This tells your brain it\'s time for sleep, not smoke.',
    },
    financialWin:
      'Better sleep means better decisions and more energy tomorrow. The value of good health is priceless, but you\'re also saving money with every cigarette you don\'t smoke.',
    healthFact:
      'Deep sleep is when your body does most of its healing and repair. By improving your sleep, you are accelerating your recovery from the damage caused by smoking.',
    checklist: [
      { id: 'day13-remedy', label: 'Drink chamomile tea before bed' },
      { id: 'day13-evening', label: 'Implement a "Digital Sunset"' },
      { id: 'day13-mindset', label: 'Do a "Brain Dump" if needed' },
    ],
    image: { id: 'day13' },
  },
  {
    day: 14,
    title: 'Two-Week Milestone: Reflect & Reward',
    theme: "You've made it two weeks! This is a massive achievement. Today is about acknowledging your hard work, celebrating your success, and reinforcing your motivation.",
    remedy: {
      title: 'Celebratory Pineapple-Mint Smoothie',
      description:
        'A delicious, tropical-tasting reward that\'s packed with vitamins. The natural sweetness helps with sugar cravings, and the vibrant flavor is a celebration for your healing taste buds.',
      recipe: [
        'Blend: 1 cup frozen pineapple, a small handful of fresh mint leaves, 1/2 banana, and 1 cup of coconut water or regular water.',
        'Serve in a nice glass and enjoy your success!',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (20 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Review and Rewrite Your "Why". Look at your "Why" list from Day 1. Has anything changed? Add new reasons. What are the best parts of being a non-smoker so far? Write them down.',
        },
        {
          type: 'Action',
          description:
            'Plan Your Reward. You have saved a significant amount of money. Decide on a specific, healthy reward you will buy with it (e.g., new running shoes, a massage, a nice dinner out).',
        },
      ],
    },
    medicalGuidance:
      'You\'re doing great. Continue with your medication as planned. Do not stop early just because you feel better. Completing the full course is key to preventing relapse.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The "Look How Far I\'ve Come" Method',
      description:
        'If a craving appears, stop and look at your savings. Think about your improved breathing. Remind yourself: "I have been a non-smoker for two weeks. I am not going back."',
    },
    financialWin:
      "At two weeks, you've likely saved enough for a significant treat. This proves that you are capable of turning a costly habit into tangible rewards.",
    healthFact:
      'At the two-week mark, your risk of heart attack has dropped significantly. Your lung function has improved by up to 30%, and walking is easier.',
    checklist: [
      { id: 'day14-remedy', label: 'Make the Celebratory Smoothie' },
      { id: 'day14-mindset', label: 'Review and update my "Why" list' },
      { id: 'day14-action', label: 'Plan or purchase my two-week reward' },
    ],
    image: { id: 'day14' },
  },
  {
    day: 15,
    title: 'The Healthy Snacking Habit',
    theme:
      "Many ex-smokers worry about weight gain. Today is about building a strategy for healthy snacking to fuel your body and keep cravings at bay.",
    remedy: {
      title: 'The "Quit Kit" Snack Box',
      description: 'Prepare a go-to box of healthy snacks. Having this ready prevents you from reaching for unhealthy options when a craving or hunger strikes.',
      recipe: [
        'Get a small container with dividers.',
        'Fill it with: a small handful of almonds or walnuts, 1/2 cup of baby carrots, and a handful of grapes or berries.',
        'Keep this with you at your desk or in your bag.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Hunger vs. Craving. Before you eat, ask yourself: "Am I truly hungry, or is this a craving?" If it\'s a craving, try drinking a glass of water and waiting 10 minutes. If you\'re still hungry, reach for your snack box.',
        },
        {
          type: 'Physical',
          description: 'The Metabolism-Boosting Burst. Do a quick 5-minute workout: 1 minute of jumping jacks, 1 minute of high knees, 1 minute of push-ups (on knees is fine), 1 minute of squats, and 1 minute of plank. This boosts metabolism and kills cravings.',
        },
      ],
    },
    medicalGuidance:
      'Some quit-smoking medications can affect appetite. Eating small, healthy snacks throughout the day can help stabilize your blood sugar and mood.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Crunchy Carrot',
      description:
        'Sometimes you just need to crunch on something. The physical act of chewing a crunchy carrot or celery stick can satisfy the oral fixation component of a craving.',
    },
    financialWin:
      'Healthy snacks like carrots and almonds are far cheaper per serving than junk food or cigarettes. You are building habits that save you money in multiple ways.',
    healthFact:
      'The oxygen-carrying capacity of your blood is now normal. This means your muscles and brain are getting more of what they need to function optimally.',
    checklist: [
      { id: 'day15-remedy', label: 'Prepare my "Quit Kit" snack box' },
      { id: 'day15-mindset', label: 'Practice distinguishing hunger from cravings' },
      { id: 'day15-physical', label: 'Do the 5-minute metabolism burst' },
    ],
    image: { id: 'day15' },
  },
  {
    day: 16,
    title: 'Conquer the Car',
    theme:
      'For many, the car is a major trigger zone. Today we reclaim that space and make it a safe, smoke-free environment.',
    remedy: {
      title: 'The "Car Quit Kit"',
      description:
        'Turn your car into a craving-fighting machine. This isn\'t a recipe, but an assembly of tools.',
      recipe: [
        'Place a bottle of water in your cup holder.',
        'Have a pack of sugar-free gum or mints in your console.',
        'Put a healthy, crunchy snack like sunflower seeds (in the shell) or a small bag of pretzels in your glove box.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (During your drive)',
      tasks: [
        {
          type: 'During drive',
          description:
            'Music or Podcast Power. Create a new playlist of upbeat, sing-along songs or download an interesting podcast. Actively listening gives your brain something else to do.',
        },
        {
          type: 'Practice',
          description:
            'Deep Breathing at Red Lights. Every time you stop at a red light, take one slow, deep breath: inhale for 4, hold for 4, exhale for 6. This resets your nervous system.',
        },
      ],
    },
    medicalGuidance:
      'If driving is a strong trigger, make sure you have your short-acting NRT (gum, lozenge, inhaler) easily accessible. The inhaler can be particularly helpful as it mimics the hand-to-mouth action.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Sensory Switch',
      description: 'Engage a different sense. Turn up the music, sing loudly, or chew a piece of intensely flavored gum. The new sensory input can override the craving signal.',
    },
    financialWin:
      'Your car no longer smells of stale smoke. This increases its resale value and saves you money on expensive detailing services.',
    healthFact:
      'Cleaning your car of smoke residue reduces "thirdhand smoke," the toxic particles that cling to surfaces and continue to harm you and your passengers long after a cigarette is out.',
    checklist: [
      { id: 'day16-remedy', label: 'Assemble my "Car Quit Kit"' },
      { id: 'day16-drive', label: 'Listen to a new playlist or podcast while driving' },
      { id: 'day16-practice', label: 'Practice deep breathing at red lights' },
    ],
    image: { id: 'day16' },
  },
  {
    day: 17,
    title: 'Mindful Meals',
    theme:
      'The after-meal cigarette is a powerful trigger. Today we create a new ritual that is satisfying and healthy.',
    remedy: {
      title: 'The Post-Meal Peppermint Tea',
      description:
        'Revisiting our friend from Day 2. The strong, clean flavor of peppermint acts as a powerful palate cleanser, signaling the end of the meal and reducing the desire for a cigarette.',
      recipe: [
        'After each meal today, brew a cup of peppermint tea.',
        'Sip it slowly and mindfully, noticing the clean feeling it leaves in your mouth.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (After meals)',
      tasks: [
        {
          type: 'After meals',
          description:
            'Change of Scenery. As soon as you finish eating, get up from the table. Go to a different room, brush your teeth, or step outside for a breath of fresh air (without a cigarette).',
        },
        {
          type: 'Action',
          description:
            'The 5-Minute Rule. After your meal, set a timer for 5 minutes and do something from your "Boredom Buster" list. The craving will likely pass before the timer goes off.',
        },
      ],
    },
    medicalGuidance:
      'If after-meal cravings are tough, this is another ideal time to use your short-acting NRT. Using it 10-15 minutes before you finish eating can pre-empt the craving.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Toothbrush Trick',
      description:
        'Immediately after eating, go and brush your teeth. The clean, minty taste is incompatible with the taste of a cigarette and provides a powerful "reset" signal to your brain.',
    },
    financialWin:
      'Every meal you finish without a cigarette is a win. You are enjoying your food more and not immediately spending money to damage your health.',
    healthFact:
      'Your sense of taste is now significantly improved. You can better appreciate the complex flavors in your food, making meals more enjoyable.',
    checklist: [
      { id: 'day17-remedy', label: 'Drink peppermint tea after each meal' },
      { id: 'day17-scenery', label: 'Change my location immediately after eating' },
      { id: 'day17-brush', label: 'Try the "Toothbrush Trick" after one meal' },
    ],
    image: { id: 'day17' },
  },
  {
    day: 18,
    title: 'Handling Slips & Building Resilience',
    theme:
      "A slip is not a failure. It's a learning opportunity. Today is about creating a plan to get back on track immediately if you have a moment of weakness.",
    remedy: {
      title: 'Forgiveness Tea (Chamomile & Ginger)',
      description:
        'This is a symbolic remedy. It combines the calming properties of chamomile with the stomach-settling effects of ginger. It\'s about being kind to yourself and resetting.',
      recipe: [
        'Pour hot water over 1 chamomile tea bag and 2 slices of fresh ginger.',
        'Let steep for 5 minutes. Drink it while reflecting on your progress.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Analyze, Don\'t Agonize. Think about a tough craving you had. What was the trigger? What did you do? What could you do differently next time? Write it down as a lesson, not a judgment.',
        },
        {
          type: 'Action',
          description: 'Create Your "Get Back on Track" Plan. Write down 3 simple steps to take if you slip. Example: 1. Throw away the rest of the pack. 2. Text my support person. 3. Re-read my "Why" list.',
        },
      ],
    },
    medicalGuidance:
      'If you slip, do not stop your medication. It is your most important tool to prevent a full relapse. A slip is the exact moment your medication is designed to help you.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Immediate Reset',
      description:
        'If you have a cigarette, the craving cycle is not over. The most important cigarette to avoid is the *second* one. Immediately implement your "Get Back on Track" plan.',
    },
    financialWin:
      'Even if you slip and buy a pack, getting back on track immediately still saves you thousands of dollars compared to a full relapse.',
    healthFact:
      'One cigarette doesn\'t erase the 18 days of healing your body has done. Your lungs are still cleaner, your circulation is still better. Get back on track and continue the healing.',
    checklist: [
      { id: 'day18-mindset', label: 'Analyze a past craving without judgment' },
      { id: 'day18-action', label: 'Write my "Get Back on Track" plan' },
      { id: 'day18-remedy', label: 'Reflect on my progress' },
    ],
    image: { id: 'day18' },
  },
  {
    day: 19,
    title: 'The Future Non-Smoker',
    theme:
      "You've almost made it. Now, let's look to the future. What does your life look like in 1, 5, and 10 years as a non-smoker? Make it vivid.",
    remedy: {
      title: 'Vibrant Vitamin C Juice',
      description:
        'A bright, forward-looking drink. This mix of citrus and berries is packed with antioxidants and Vitamin C, helping to repair cellular damage from smoking.',
      recipe: [
        'Juice or blend: 1 peeled orange, 1/2 cup of strawberries, and the juice of half a lemon.',
        'Add a splash of water if blending to reach desired consistency.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (15 minutes)',
      tasks: [
        {
          type: 'Mindset',
          description:
            'Letter to My Future Self. Write a short letter to yourself one year from now. Describe your pride in staying smoke-free, the health benefits you feel, and what you did with the money you saved.',
        },
        {
          type: 'Action',
          description:
            'Plan a Healthy Goal. What physical activity can you do now that you couldn\'t before? Sign up for a 5k walk, plan a hike, or commit to a weekly bike ride. Put it on the calendar.',
        },
      ],
    },
    medicalGuidance:
      'Start thinking about a plan to taper off your NRT with your doctor or pharmacist. This is usually done slowly over several weeks *after* your initial quit period is stable.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Focus on the Goal',
      description: 'When a craving hits, pull out the "Letter to My Future Self" or look at the race/hike you put on your calendar. Remind yourself that a momentary craving is not worth sacrificing your future.',
    },
    financialWin:
      'Calculate your 1-year savings. It\'s likely over a thousand dollars. What major goal can that money accomplish? A new laptop? A weekend trip? Start planning.',
    healthFact:
      'After one year of being smoke-free, your risk of a heart attack is cut in half. After 5 years, your stroke risk is the same as a non-smoker\'s.',
    checklist: [
      { id: 'day19-remedy', label: 'Drink the Vibrant Vitamin C juice' },
      { id: 'day19-mindset', label: 'Write the letter to my future self' },
      { id: 'day19-action', label: 'Set a new physical fitness goal' },
    ],
    image: { id: 'day19' },
  },
  {
    day: 20,
    title: 'The Sweet Taste of Success',
    theme:
      "You've rewired your brain and body. Your taste buds are fully alive. Today is about enjoying the simple, sweet pleasures of a smoke-free life.",
    remedy: {
      title: 'Strawberry-Banana "Nice Cream"',
      description: 'A healthy, delicious dessert that you can enjoy guilt-free. It satisfies sugar cravings and celebrates your improved sense of taste.',
      recipe: [
        'Blend 2 frozen bananas (cut into chunks) with 1 cup of frozen strawberries and a tiny splash of milk or water.',
        'Blend until it reaches a smooth, soft-serve consistency. You may need to stop and scrape down the sides.',
        'Enjoy immediately!',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (Flexible)',
      tasks: [
        {
          type: 'Action',
          description:
            'The Flavor Test. Eat a piece of your favorite fruit. Close your eyes and try to identify all the different flavors. Notice how much more vibrant it tastes now compared to three weeks ago.',
        },
        {
          type: 'Mindset',
          description:
            'Gratitude List. Write down 5 things you are grateful for about your smoke-free life. Examples: "I don\'t have to stand in the cold to smoke," "My car smells clean," "I can taste my coffee."',
        },
      ],
    },
    medicalGuidance:
      'You have successfully used medication to help you quit. Be proud of that. Continue to use it as directed and follow your tapering plan when the time is right.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: Savor the Flavor',
      description:
        'If a craving hits, pop a strong sugar-free mint or a piece of dark chocolate in your mouth. Focus entirely on the intense flavor. It\'s a sensory experience that smoking can\'t compete with.',
    },
    financialWin:
      "You are on the verge of completing the 21-day challenge. The money saved is no longer a projection; it's real. Make a plan for how you will continue to track and use these savings.",
    healthFact:
      'Your risk of various cancers—including mouth, throat, esophagus, and bladder—is cut in half within 5 years of quitting.',
    checklist: [
      { id: 'day20-remedy', label: 'Make and enjoy the "Nice Cream"' },
      { id: 'day20-action', label: 'Do the "Flavor Test"' },
      { id: 'day20-mindset', label: 'Write my gratitude list' },
    ],
    image: { id: 'day20' },
  },
  {
    day: 21,
    title: 'Freedom: Plan for a Smoke-Free Future',
    theme:
      "Congratulations! You have completed the 21-day challenge. You are a non-smoker. Today is about creating a plan to protect your freedom for life.",
    remedy: {
      title: 'Your Personal "Freedom" Ritual',
      description:
        "What healthy ritual have you enjoyed most? The morning walk? The after-dinner tea? The celebratory smoothie? Make that your new, permanent ritual.",
      recipe: [
        'Choose the recipe or activity from the past 21 days that made you feel the best.',
        'Incorporate it into your daily or weekly routine, starting today.',
      ],
    },
    mindBodyFocus: {
      title: 'Mind & Body Focus (20 minutes)',
      tasks: [
        {
          type: 'Action',
          description:
            'Create Your Maintenance Plan. What will you do if a major stressor occurs? Who will you call? What is your emergency craving strategy? Write it down.',
        },
        {
          type: 'Mindset',
          description:
            'Identify as a Non-Smoker. Say it out loud: "I am a non-smoker." Notice how it feels. This is your new identity. Own it.',
        },
      ],
    },
    medicalGuidance:
      'Schedule a follow-up with your doctor to discuss your success and your plan for tapering off medication. Celebrate this victory with them.',
    cravingBuster: {
      title: 'Your Craving-Buster Strategy: The Full Toolkit',
      description: 'You now have a full toolkit of strategies: The 4 D\'s, calling a friend, physical activity, mindfulness, and more. You are prepared for anything. Trust your training.',
    },
    financialWin:
      'You did it. Three weeks of savings. Transfer that money to a savings account or use it for the reward you planned. You have earned this in every sense of the word.',
    healthFact:
      'Within 10-15 years, your risk of lung cancer is cut in half, and your risk of dying from it is similar to that of someone who has never smoked. Your future is healthier, longer, and richer.',
    checklist: [
      { id: 'day21-remedy', label: 'Perform my new "Freedom" Ritual' },
      { id: 'day21-action', label: 'Write my maintenance plan' },
      { id: 'day21-mindset', label: 'Declare "I am a non-smoker"' },
      { id: 'day21-celebrate', label: 'Celebrate this amazing achievement!' },
    ],
    image: { id: 'day21' },
  },
];
