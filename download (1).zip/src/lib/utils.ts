import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

const CIGARETTES_PER_PACK = 20;

export function calculateDailySavings(cigarettesPerDay: number, pricePerPack: number): number {
  if (pricePerPack <= 0 || cigarettesPerDay <= 0) return 0;
  const packsPerDay = cigarettesPerDay / CIGARETTES_PER_PACK;
  return packsPerDay * pricePerPack;
}

export function calculateTotalSavings(cigarettesPerDay: number, pricePerPack: number, days: number): number {
  if (days < 0) return 0;
  const dailySavings = calculateDailySavings(cigarettesPerDay, pricePerPack);
  return dailySavings * days;
}

export function calculateCigarettesAvoided(cigarettesPerDay: number, days: number): number {
  if (days < 0) return 0;
  return cigarettesPerDay * days;
}
