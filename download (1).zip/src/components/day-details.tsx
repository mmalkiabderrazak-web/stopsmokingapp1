'use client';

import type { DayPlan, MindBodyFocusTask } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Image from 'next/image';
import placeholderData from '@/lib/placeholder-images.json';
import { Badge } from '@/components/ui/badge';
import { ClipboardList, DollarSign, HeartPulse, ShieldAlert, BrainCircuit, Target, Stethoscope, Dumbbell, ArrowLeft } from 'lucide-react';
import Checklist from './checklist';
import Link from 'next/link';
import { Button } from './ui/button';

const iconMap: Record<MindBodyFocusTask['type'], React.ReactNode> = {
  Mindset: <BrainCircuit className="h-5 w-5 text-primary" />,
  Physical: <Dumbbell className="h-5 w-5 text-primary" />,
  Action: <Target className="h-5 w-5 text-primary" />,
  'All Day': <ClipboardList className="h-5 w-5 text-primary" />,
  Morning: <ClipboardList className="h-5 w-5 text-primary" />,
  Evening: <ClipboardList className="h-5 w-5 text-primary" />,
  Practice: <ClipboardList className="h-5 w-5 text-primary" />,
  Flexible: <ClipboardList className="h-5 w-5 text-primary" />,
  'During drive': <ClipboardList className="h-5 w-5 text-primary" />,
  'After meals': <ClipboardList className="h-5 w-5 text-primary" />,
};

const MindBodyIcon = ({ type }: { type: MindBodyFocusTask['type'] }) => {
  return iconMap[type] || <ClipboardList className="h-5 w-5 text-primary" />;
};

export default function DayDetails({ dayData }: { dayData: DayPlan }) {
  const imageMeta = placeholderData.placeholderImages.find(img => img.id === dayData.image.id);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <main className="container mx-auto p-4 md:p-8">
        <div className="mb-8">
          <Button asChild variant="outline" className="mb-4">
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
          <header className="relative overflow-hidden rounded-2xl shadow-lg animate-fade-in-down">
            {imageMeta && (
              <Image
                src={imageMeta.imageUrl}
                alt={imageMeta.description}
                width={600}
                height={400}
                className="w-full h-48 md:h-64 object-cover"
                data-ai-hint={imageMeta.imageHint}
                priority
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-0 p-4 md:p-6 text-white">
              <Badge variant="secondary" className="mb-2">Day {dayData.day}</Badge>
              <h1 className="text-3xl md:text-4xl font-bold">{dayData.title}</h1>
              <p className="mt-2 text-base md:text-lg text-white/90">{dayData.theme}</p>
            </div>
          </header>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
             <Card className="animate-fade-in-up" style={{ animationDelay: '100ms'}}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <span role="img" aria-label="herb emoji" className='text-2xl'>🌿</span> Your Daily Natural Remedy
                </CardTitle>
                <CardDescription>{dayData.remedy.title}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{dayData.remedy.description}</p>
                <h4 className="font-semibold mb-2">Recipe:</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  {dayData.remedy.recipe.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up" style={{ animationDelay: '200ms'}}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <span role="img" aria-label="muscle emoji" className='text-2xl'>💪</span> {dayData.mindBodyFocus.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {dayData.mindBodyFocus.tasks.map((task, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="mt-1">
                      <MindBodyIcon type={task.type} />
                    </div>
                    <div>
                      <h4 className="font-semibold">{task.type} Task</h4>
                      <p className="text-muted-foreground">{task.description}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up" style={{ animationDelay: '400ms'}}>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Stethoscope className="h-5 w-5 text-primary" />
                        Medical Guidance
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">{dayData.medicalGuidance}</p>
                </CardContent>
            </Card>
          </div>
          
          <div className="space-y-6">
             <Card className="animate-fade-in-up" style={{ animationDelay: '300ms'}}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldAlert className="h-6 w-6 text-accent" />
                  {dayData.cravingBuster.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{dayData.cravingBuster.description}</p>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up" style={{ animationDelay: '500ms'}}>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5 text-green-600" />
                        Financial Win
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">{dayData.financialWin}</p>
                </CardContent>
            </Card>
            
            <Card className="animate-fade-in-up" style={{ animationDelay: '600ms'}}>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <HeartPulse className="h-5 w-5 text-red-500" />
                        Health Fact
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">{dayData.healthFact}</p>
                </CardContent>
            </Card>

            <Checklist day={dayData.day} items={dayData.checklist} />

          </div>
        </div>
      </main>
    </div>
  );
}
