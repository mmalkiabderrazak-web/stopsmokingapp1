'use client';

import { useApp } from '@/contexts/app-provider';
import { daysData } from '@/lib/days-data';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Lock } from 'lucide-react';

const emojiMap: { [key: number]: string } = {
  1: '🎯', 2: '🤝', 3: '💊', 4: '🔍', 5: '🧹', 6: '🎭', 7: '🏁',
  8: '⚡️', 9: '🧘', 10: '💡', 11: '🥂', 12: '🎁', 13: '🌙', 14: '✅',
  15: '🎨', 16: '🚗', 17: '🍽️', 18: '❤️‍🩹', 19: '🛠️', 20: '🌟', 21: '🚀'
};


export default function DashboardGrid() {
  const { user, isChecklistCompleted } = useApp();
  if (!user) return null;
  
  const getChecklistProgressForDay = (dayNumber: number): number => {
    const dayData = daysData.find(d => d.day === dayNumber);
    if (!dayData || dayData.checklist.length === 0) {
      return 100;
    }
    const completedCount = dayData.checklist.filter(item => isChecklistCompleted(dayNumber, item.id)).length;
    return (completedCount / dayData.checklist.length) * 100;
  };

  const findLastCompletedDay = () => {
    let lastCompletedDay = 0;
    for (let i = 1; i <= 21; i++) {
        if (getChecklistProgressForDay(i) === 100) {
            lastCompletedDay = i;
        } else {
            break;
        }
    }
    return lastCompletedDay;
  };
  
  const lastCompletedDay = findLastCompletedDay();
  const currentDayOfJourney = lastCompletedDay + 1;

  const isDayUnlocked = (dayNumber: number): boolean => {
    return dayNumber <= currentDayOfJourney;
  };

  const isCurrentDay = (dayNumber: number) => {
    return currentDayOfJourney === dayNumber;
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      {daysData.map(day => {
        const isUnlocked = isDayUnlocked(day.day);
        const isActive = isCurrentDay(day.day);

        return (
          <div key={day.day} className="animate-fade-in-up" style={{ animationDelay: `${(day.day - 1) * 50}ms`}}>
            <Link href={isUnlocked ? `/day/${day.day}` : '#'} aria-disabled={!isUnlocked} tabIndex={isUnlocked ? 0 : -1} className={`block h-full ${!isUnlocked ? 'pointer-events-none' : ''}`}>
              <Card 
                className={`h-full transition-all duration-300 shadow-md rounded-2xl ${
                  isUnlocked 
                    ? `bg-card-bg ${isActive ? 'border-2 border-primary' : 'border-transparent'}`
                    : 'bg-muted/50 border-transparent'
                }`}
              >
                <CardContent className="p-4 text-left">
                  <div className={`mb-2 flex items-center justify-between`}>
                      <div className={`flex h-10 w-10 items-center justify-center rounded-full text-xl ${
                          isUnlocked ? 'bg-primary/10' : 'bg-black/10'
                        }`}>
                        {emojiMap[day.day]}
                      </div>
                      {!isUnlocked && <Lock className="w-5 h-5 text-text-secondary/50" />}
                  </div>
                  <p className={`text-xs font-semibold ${isUnlocked ? 'text-primary' : 'text-text-secondary/50'}`}>Day {day.day}</p>
                  <p className={`text-sm font-semibold leading-tight mt-1 ${isUnlocked ? 'text-text-primary' : 'text-text-secondary/50'}`}>
                    {day.title}
                  </p>
                </CardContent>
              </Card>
            </Link>
          </div>
        );
      })}
    </div>
  );
}
