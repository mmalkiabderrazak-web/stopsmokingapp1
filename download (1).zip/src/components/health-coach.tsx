
'use client';
import { useState, useEffect, useRef } from 'react';

const HealthCoach = () => {
    const API_KEY = process.env.NEXT_PUBLIC_OPENROUTER_API_KEY;
    const API_URL = "https://openrouter.ai/api/v1/chat/completions";

    const programData = {
        1: {
            theme: "Commit & Map Your 'Why'",
            remedy: "Citrus-Mint Water",
            focus: "Create your 'Why' list - reasons you're quitting",
            strategy: "4 D's: Delay, Deep Breathe, Drink Water, Do Something Else"
        },
        7: {
            theme: "QUIT DAY!",
            remedy: "Orange-Carrot-Ginger Juice",
            focus: "Stay busy, use medication as directed, text support team",
            strategy: "Emergency Protocol: 4 D's + NRT + support call"
        },
        14: {
            theme: "Two-Week Milestone",
            remedy: "Pineapple-Mint Smoothie",
            focus: "Reflect on progress, celebrate achievements",
            strategy: "Remember the health benefits when cravings hit"
        },
        21: {
            theme: "Celebrate & Plan Future",
            remedy: "Your Favorite Ritual",
            focus: "Write your maintenance plan, schedule follow-up",
            strategy: "Use all strategies learned if urges strike"
        }
    };
    
    const [conversationHistory, setConversationHistory] = useState([
        {
            role: "system",
            content: `You are Quit Coach, an AI specialized in smoking cessation through a 21-day program. Keep responses concise for mobile. For program questions (days 1-21), use program data. For other questions, provide brief, evidence-based smoking cessation advice. Never provide medical advice outside this scope. Use encouraging, supportive tone.`
        }
    ]);
    
    const [messages, setMessages] = useState<Array<{text: string, isUser: boolean}>>([]);
    const [isTyping, setIsTyping] = useState(false);

    const messagesContainerRef = useRef<HTMLDivElement>(null);
    const userInputRef = useRef<HTMLInputElement>(null);
    const sendBtnRef = useRef<HTMLButtonElement>(null);
    const apiStatusRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        addMessage("Hi! I'm your Quit Coach. I can help with the 21-day program or answer questions about quitting smoking. What would you like to know? 💪", false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (messagesContainerRef.current) {
            messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
        }
    }, [messages, isTyping]);

    const addMessage = (text: string, isUser: boolean) => {
        setMessages(prev => [...prev, { text, isUser }]);
    };

    const sendMessage = async () => {
        if (!userInputRef.current) return;
        const message = userInputRef.current.value.trim();
        if (!message) return;

        addMessage(message, true);
        userInputRef.current.value = '';
        
        const updatedHistory = [...conversationHistory, { role: "user", content: message }];
        setConversationHistory(updatedHistory);

        setIsTyping(true);
        setSendButtonLoading(true);

        try {
            const programResponse = checkProgramKnowledge(message);
            if (programResponse) {
                setTimeout(() => {
                    setIsTyping(false);
                    addMessage(programResponse, false);
                    setConversationHistory(prev => [...prev, { role: "assistant", content: programResponse }]);
                    setSendButtonLoading(false);
                }, 600);
                return;
            }

            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${API_KEY}`,
                    "Content-Type": "application/json",
                    "HTTP-Referer": typeof window !== 'undefined' ? window.location.origin : '',
                    "X-Title": "Quit Coach"
                },
                body: JSON.stringify({
                    "model": "openai/gpt-3.5-turbo",
                    "messages": updatedHistory,
                    "max_tokens": 300,
                    "temperature": 0.7
                })
            });

            if (!response.ok) {
                throw new Error(`API request failed: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.choices && data.choices[0] && data.choices[0].message) {
                const aiResponse = data.choices[0].message.content;
                setConversationHistory(prev => [...prev, { role: "assistant", content: aiResponse }]);
                addMessage(aiResponse, false);
                if (apiStatusRef.current) {
                    apiStatusRef.current.textContent = "AI Coach Connected";
                    apiStatusRef.current.style.color = "#38a169";
                }
            } else {
                throw new Error('Invalid response format');
            }

        } catch (error) {
            console.error('API Error:', error);
            if (apiStatusRef.current) {
                apiStatusRef.current.textContent = "Connection Issue - Using Program Knowledge";
                apiStatusRef.current.style.color = "#d69e2e";
            }
            const fallbackResponse = getFallbackResponse(message);
            addMessage(fallbackResponse, false);
            setConversationHistory(prev => [...prev, { role: "assistant", content: fallbackResponse }]);
        } finally {
            setIsTyping(false);
            setSendButtonLoading(false);
        }
    };

    function checkProgramKnowledge(message: string) {
        const lowerMessage = message.toLowerCase();
        
        const dayMatch = lowerMessage.match(/day\s*(\d+)/);
        if (dayMatch) {
            const dayNum = parseInt(dayMatch[1]);
            if (programData[dayNum as keyof typeof programData]) {
                return formatDayResponse(dayNum);
            } else if (dayNum >= 1 && dayNum <= 21) {
                return `I have info for Day ${dayNum}! The program helps you quit step by step. Which aspect interests you most?`;
            } else {
                return `I have detailed plans for days 1-21! Which day are you on?`;
            }
        }
        
        if (lowerMessage.includes('craving') || lowerMessage.includes('urge')) {
            return `Cravings are temporary! Try the 4 D's: Delay (10 min), Deep Breathe, Drink Water, Do Something Else. You've got this! 💪`;
        }
        
        if (lowerMessage.includes('withdrawal')) {
            return `Withdrawal symptoms are normal and temporary. Stay hydrated, distract yourself, and remember they mean your body is healing. 🌱`;
        }
        
        if (lowerMessage.includes('quit smoking') || lowerMessage.includes('stop smoking')) {
            return `The 21-day program guides you step by step to quit smoking. Let's do this together! Which day are you on?`;
        }
        
        if (lowerMessage.includes('recipe') || lowerMessage.includes('juice') || lowerMessage.includes('smoothie')) {
            return `The program includes healthy recipes like Citrus-Mint Water and fruit smoothies to help with quitting. Which day interests you?`;
        }
        
        return null;
    }

    function getFallbackResponse(message: string) {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('quit') || lowerMessage.includes('smoking')) {
            return `I'm here to help you quit smoking! The 21-day program makes it manageable. Let's start with where you are in the process.`;
        }
        
        if (lowerMessage.includes('help') || lowerMessage.includes('support')) {
            return `I'm here to support your quit journey! Whether it's cravings, withdrawal, or motivation, I can help. What's challenging right now?`;
        }
        
        return "My apologies, I'm having trouble connecting. Please try again later. For now, feel free to ask me anything about the 21-day program itself!";
    }

    function formatDayResponse(dayNum: number) {
        const day = programData[dayNum as keyof typeof programData];
        let response = `<div class="day-tag">Day ${dayNum} - ${day.theme}</div>`;
        
        response += `<div class="info-card"><h4>🌿 Remedy</h4><p>${day.remedy}</p></div>`;
        response += `<div class="info-card"><h4>💡 Focus</h4><p>${day.focus}</p></div>`;
        response += `<div class="strategy-card"><h4>🛡️ Strategy</h4><p>${day.strategy}</p></div>`;
        
        return response;
    }

    const setSendButtonLoading = (loading: boolean) => {
        const sendBtn = sendBtnRef.current;
        if (!sendBtn) return;
        if (loading) {
            sendBtn.innerHTML = `⏳`;
            sendBtn.disabled = true;
        } else {
            sendBtn.innerHTML = `✈️`;
            sendBtn.disabled = false;
        }
    };
    
    const sendQuickMessage = (message: string) => {
        if(userInputRef.current) {
            userInputRef.current.value = message;
            sendMessage();
        }
    };

    return (
        <>
            <style jsx global>{`
                .chat-container * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                    font-family: 'Segoe UI', system-ui, sans-serif;
                }
                .chat-container-wrapper {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100%;
                    width: 100%;
                }
                .chat-container {
                    width: 100%;
                    max-width: 360px;
                    height: 640px;
                    background: #ffffff;
                    border-radius: 20px;
                    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
                    display: flex;
                    flex-direction: column;
                    overflow: hidden;
                }
                .header {
                    background: linear-gradient(135deg, #6C63FF 0%, #4A43C9 100%);
                    color: white;
                    padding: 18px 15px;
                    text-align: center;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                }
                .profile {
                    display: flex;
                    align-items: center;
                }
                .avatar {
                    width: 42px;
                    height: 42px;
                    border-radius: 50%;
                    background: white;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-right: 10px;
                    font-size: 24px;
                }
                .profile-info h1 {
                    font-size: 18px;
                    font-weight: 700;
                    margin-bottom: 2px;
                }
                .profile-info p {
                    font-size: 12px;
                    opacity: 0.9;
                }
                .status-dot {
                    width: 8px;
                    height: 8px;
                    background: #4ADE80;
                    border-radius: 50%;
                    margin-right: 5px;
                }
                .status {
                    display: flex;
                    align-items: center;
                    font-size: 11px;
                    opacity: 0.9;
                }
                .chat-area {
                    flex: 1;
                    padding: 15px;
                    overflow-y: auto;
                    background: #f8f9ff;
                    display: flex;
                    flex-direction: column;
                }
                .welcome-message {
                    background: white;
                    padding: 15px;
                    border-radius: 15px;
                    margin-bottom: 15px;
                    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
                    border: 1px solid #e6e9ff;
                }
                .welcome-message h3 {
                    color: #6C63FF;
                    margin-bottom: 8px;
                    font-size: 16px;
                    font-weight: 600;
                }
                .welcome-message p {
                    color: #5a5a7a;
                    line-height: 1.4;
                    font-size: 13px;
                    margin-bottom: 10px;
                }
                .quick-actions {
                    display: flex;
                    gap: 8px;
                    margin-top: 12px;
                    flex-wrap: wrap;
                }
                .quick-btn {
                    background: white;
                    border: 1px solid #e6e9ff;
                    padding: 6px 10px;
                    border-radius: 15px;
                    font-size: 11px;
                    color: #6C63FF;
                    cursor: pointer;
                    transition: all 0.3s;
                    font-weight: 500;
                }
                .quick-btn:hover {
                    background: #6C63FF;
                    color: white;
                }
                .input-area {
                    padding: 15px;
                    background: white;
                    border-top: 1px solid #e6e9ff;
                }
                .input-container {
                    display: flex;
                    gap: 10px;
                    align-items: center;
                }
                .input-container input {
                    flex: 1;
                    padding: 12px 15px;
                    border: 1px solid #e6e9ff;
                    border-radius: 25px;
                    outline: none;
                    font-size: 14px;
                    background: #f8f9ff;
                }
                .input-container input:focus {
                    background: white;
                    border-color: #6C63FF;
                }
                .send-btn {
                    width: 42px;
                    height: 42px;
                    background: linear-gradient(135deg, #6C63FF 0%, #4A43C9 100%);
                    border: none;
                    border-radius: 50%;
                    color: white;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 18px;
                }
                .message {
                    max-width: 85%;
                    padding: 10px 14px;
                    border-radius: 15px;
                    line-height: 1.4;
                    font-size: 13px;
                    margin-bottom: 10px;
                    position: relative;
                }
                .message.user {
                    align-self: flex-end;
                    background: linear-gradient(135deg, #6C63FF 0%, #4A43C9 100%);
                    color: white;
                    border-bottom-right-radius: 5px;
                }
                .message.bot {
                    align-self: flex-start;
                    background: white;
                    color: #33334d;
                    border: 1px solid #e6e9ff;
                    border-bottom-left-radius: 5px;
                }
                .typing-indicator {
                    padding: 10px;
                    color: #a8a8c7;
                    font-size: 12px;
                    font-style: italic;
                    display: ${isTyping ? 'block' : 'none'};
                }
                .messages-container {
                    display: flex;
                    flex-direction: column;
                }
                .day-tag {
                    background: linear-gradient(45deg, #FF6B6B, #FF8E8E);
                    color: white;
                    padding: 4px 10px;
                    border-radius: 12px;
                    font-size: 11px;
                    font-weight: 600;
                    margin-bottom: 8px;
                    display: inline-block;
                }
                .info-card {
                    background: #f0f3ff;
                    border-left: 3px solid #6C63FF;
                    padding: 10px;
                    margin: 8px 0;
                    border-radius: 10px;
                }
                .info-card h4 {
                    color: #6C63FF;
                    margin-bottom: 5px;
                    font-size: 13px;
                    font-weight: 600;
                }
                .info-card p {
                    color: #5a5a7a;
                    font-size: 12px;
                    line-height: 1.4;
                }
                .recipe-card {
                    background: #f0f8ff;
                    border: 1px solid #b3d9ff;
                    padding: 10px;
                    margin: 8px 0;
                    border-radius: 10px;
                }
                .recipe-card h4 {
                    color: #3399ff;
                    margin-bottom: 8px;
                    font-size: 13px;
                    font-weight: 600;
                }
                .recipe-card p {
                    color: #5a5a7a;
                    font-size: 12px;
                    line-height: 1.4;
                }
                .strategy-card {
                    background: #fff8f0;
                    border: 1px solid #ffcc99;
                    padding: 10px;
                    margin: 8px 0;
                    border-radius: 10px;
                }
                .strategy-card h4 {
                    color: #ff9933;
                    margin-bottom: 8px;
                    font-size: 13px;
                    font-weight: 600;
                }
                .strategy-card p {
                    color: #5a5a7a;
                    font-size: 12px;
                    line-height: 1.4;
                }
                .api-status {
                    font-size: 10px;
                    color: #a8a8c7;
                    text-align: center;
                    margin-top: 8px;
                }
            `}</style>
            <div className="chat-container">
                <div className="header">
                    <div className="profile">
                        <div className="avatar">
                           👨‍⚕️
                        </div>
                        <div className="profile-info">
                            <h1>Quit Coach</h1>
                            <p>Smoking Cessation</p>
                        </div>
                    </div>
                    <div className="status">
                        <div className="status-dot"></div>
                        <span>Online</span>
                    </div>
                </div>
                
                <div className="chat-area" ref={messagesContainerRef}>
                    <div className="welcome-message">
                        <h3>Welcome! 👋</h3>
                        <p>I'm your AI Quit Coach. I'll guide you through the 21-day program to quit smoking. How can I help you today?</p>
                        
                        <div className="quick-actions">
                            <button className="quick-btn" onClick={() => sendQuickMessage('Day 1 plan')}>Day 1</button>
                            <button className="quick-btn" onClick={() => sendQuickMessage('Day 7 plan')}>Quit Day</button>
                            <button className="quick-btn" onClick={() => sendQuickMessage('cravings help')}>Cravings</button>
                            <button className="quick-btn" onClick={() => sendQuickMessage('withdrawal symptoms')}>Withdrawal</button>
                        </div>
                    </div>
                    
                    <div className="messages-container">
                        {messages.map((msg, index) => (
                            <div key={index} className={`message ${msg.isUser ? 'user' : 'bot'}`} dangerouslySetInnerHTML={{ __html: msg.text }}>
                            </div>
                        ))}
                    </div>
                    
                    <div className="typing-indicator">
                        Quit Coach is thinking...
                    </div>
                </div>

                <div className="input-area">
                    <div className="input-container">
                        <input type="text" ref={userInputRef} placeholder="Ask about quitting smoking..." onKeyPress={(e) => e.key === 'Enter' && sendMessage()} />
                        <button className="send-btn" ref={sendBtnRef} onClick={sendMessage}>
                           ✈️
                        </button>
                    </div>
                    <div className="api-status" ref={apiStatusRef}>AI Coach Ready</div>
                </div>
            </div>
        </>
    );
};

export default HealthCoach;

    