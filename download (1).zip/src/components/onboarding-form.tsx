'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useApp } from '@/contexts/app-provider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';

const nameSchema = z.object({
  name: z.string().min(2, { message: "Please enter your name." }),
});
const ageSchema = z.object({
  age: z.coerce.number().min(13, { message: "You must be at least 13." }).max(100, { message: "Please enter a valid age." }),
});
const habitsSchema = z.object({
  cigarettesPerDay: z.coerce.number().min(1, { message: "Must be at least 1." }),
});
const costSchema = z.object({
  pricePerPack: z.coerce.number().min(0.1, { message: "Price must be positive." }),
});

const formSchemas = [nameSchema, ageSchema, habitsSchema, costSchema];

type OnboardingFormValues = z.infer<typeof nameSchema> &
  z.infer<typeof ageSchema> &
  z.infer<typeof habitsSchema> &
  z.infer<typeof costSchema>;

const fieldNames: (keyof OnboardingFormValues)[][] = [
  ['name'],
  ['age'],
  ['cigarettesPerDay'],
  ['pricePerPack'],
];

export default function OnboardingForm() {
  const { setUser } = useApp();
  const [step, setStep] = useState(0);

  const currentSchema = formSchemas[step];

  const form = useForm<OnboardingFormValues>({
    resolver: zodResolver(currentSchema),
    defaultValues: {
      name: '',
      age: undefined,
      cigarettesPerDay: undefined,
      pricePerPack: undefined,
    },
    mode: "onChange",
  });

  const onSubmit = (values: Partial<OnboardingFormValues>) => {
    if (step < formSchemas.length - 1) {
      setStep(step + 1);
    } else {
      setUser({
        name: values.name!,
        age: values.age!,
        cigarettesPerDay: values.cigarettesPerDay!,
        pricePerPack: values.pricePerPack!,
        startDate: new Date().toISOString(),
      });
    }
  };

  const handleNext = async () => {
    const fieldsToValidate = fieldNames[step];
    const isValid = await form.trigger(fieldsToValidate);
    if (isValid) {
      onSubmit(form.getValues());
    }
  };
  
  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  const questions = [
    { name: 'name', label: "What's your name?", placeholder: "Enter your name", type: "text" },
    { name: 'age', label: "What's your age?", placeholder: "e.g., 35", type: "number" },
    { name: 'cigarettesPerDay', label: "How many cigarettes do you smoke per day?", placeholder: "e.g., 15", type: "number" },
    { name: 'pricePerPack', label: "Price per pack in your currency ($)?", placeholder: "e.g., 8.50", type: "number" },
  ];

  const currentQuestion = questions[step];
  
  const variants = {
    hidden: { opacity: 0, x: 50 },
    visible: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -50 },
  };

  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center p-4 text-center text-text-primary" style={{backgroundColor: 'var(--main-bg)'}}>
      <div className="w-full max-w-md">
        <div className="flex justify-center items-center mb-6">
          <Heart className="w-10 h-10 text-primary" />
        </div>

        <h1 className="text-2xl font-bold">Welcome to Your Journey</h1>
        <p className="text-text-secondary mt-2 mb-8">
          You're about to embark on a life-changing 21-day journey to quit smoking. Let's get to know you.
        </p>

        <div className="flex justify-center gap-2 mb-8">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className={`h-2 w-8 rounded-full transition-colors ${
                i <= step ? 'bg-primary' : 'bg-primary/30'
              }`}
            />
          ))}
        </div>

        <Form {...form}>
          <form onSubmit={(e) => { e.preventDefault(); handleNext(); }} className="space-y-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                variants={variants}
                initial="hidden"
                animate="visible"
                exit="exit"
                transition={{ duration: 0.3 }}
              >
                <FormField
                  control={form.control}
                  name={currentQuestion.name as keyof OnboardingFormValues}
                  render={({ field: { onChange, ...field } }) => (
                    <FormItem>
                      <FormLabel className="text-left block font-semibold mb-2">{currentQuestion.label}</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder={currentQuestion.placeholder} 
                          {...field}
                          type={currentQuestion.type} 
                          className="text-base bg-white border-gray-300 placeholder:text-gray-400"
                          onChange={(e) => {
                            if (currentQuestion.type === 'number') {
                              // Allow empty string to clear input, otherwise convert to number
                              onChange(e.target.value === '' ? '' : Number(e.target.value));
                            } else {
                              onChange(e.target.value);
                            }
                          }}
                          // react-hook-form stores undefined as '', so we check for that
                          value={field.value === undefined ? '' : field.value}
                        />
                      </FormControl>
                      <FormMessage className="text-left text-red-500" />
                    </FormItem>
                  )}
                />
              </motion.div>
            </AnimatePresence>
            
            <div className="flex gap-4 pt-4">
              {step > 0 && (
                <Button type="button" onClick={handleBack} variant="outline" className="w-full bg-transparent border-primary/50 text-primary hover:bg-primary/10 hover:text-primary">
                  Back
                </Button>
              )}
              <Button type="submit" className="w-full bg-primary text-white hover:bg-primary/90" disabled={form.formState.isSubmitting}>
                {step === formSchemas.length - 1 ? "Start My Journey" : "Next"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
