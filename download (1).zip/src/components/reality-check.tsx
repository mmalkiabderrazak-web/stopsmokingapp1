'use client';

import * as React from 'react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from '@/components/ui/carousel';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, TrendingDown, HeartCrack, Clock, Wallet, Users } from 'lucide-react';
import Autoplay from "embla-carousel-autoplay"

const realityChecks = [
  {
    icon: <HeartCrack className="w-8 h-8 text-red-400" />,
    title: 'Heart Disease & Stroke',
    text: 'Smokers are 2 to 4 times more likely to develop coronary heart disease and twice as likely to have a stroke.',
  },
  {
    icon: <TrendingDown className="w-8 h-8 text-orange-400" />,
    title: 'Cancer Risk',
    text: 'Smoking is the number one cause of lung cancer. It also causes cancer of the throat, mouth, bladder, and many others.',
  },
  {
    icon: <Clock className="w-8 h-8 text-yellow-400" />,
    title: 'Lost Time',
    text: 'On average, every cigarette you smoke reduces your lifespan by 11 minutes. A pack-a-day habit can steal over 10 years of your life.',
  },
  {
    icon: <Wallet className="w-8 h-8 text-green-400" />,
    title: 'Financial Drain',
    text: 'A $10-per-pack habit costs over $3,650 a year. That money could be a vacation, a down payment, or a secure future.',
  },
  {
    icon: <Users className="w-8 h-8 text-blue-400" />,
    title: 'Social Impact',
    text: 'Secondhand smoke harms your loved ones, increasing their risk of lung cancer and heart disease. Quitting protects them, too.',
  },
  {
    icon: <AlertTriangle className="w-8 h-8 text-purple-400" />,
    title: 'Appearance',
    text: 'Smoking prematurely ages your skin, causes wrinkles, stains your teeth, and leaves a persistent odor on your clothes and breath.',
  },
];

export default function RealityCheck() {
  const plugin = React.useRef(
    Autoplay({ delay: 5000, stopOnInteraction: true })
  )
    
  return (
    <div className="mt-8">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="text-text-primary" />
        <h2 className="text-xl font-bold text-text-primary">The Harsh Reality</h2>
      </div>
      <Carousel
        plugins={[plugin.current]}
        className="w-full"
        onMouseEnter={plugin.current.stop}
        onMouseLeave={plugin.current.reset}
      >
        <CarouselContent>
          {realityChecks.map((item, index) => (
            <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
              <div className="p-1">
                <Card className="bg-white/60 border-primary/20 text-text-secondary h-full shadow-lg">
                  <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                    {item.icon}
                    <CardTitle className="text-base font-semibold text-text-primary">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-text-secondary/80">{item.text}</p>
                  </CardContent>
                </Card>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>
    </div>
  );
}
