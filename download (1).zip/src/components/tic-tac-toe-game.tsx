'use client';
import { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { DialogClose } from '@/components/ui/dialog';

const TicTacToeGame = () => {
  const [board, setBoard] = useState<Player[]>(Array(9).fill(''));
  const [currentPlayer, setCurrentPlayer] = useState<Player>('O');
  const [gameActive, setGameActive] = useState(true);
  const [scores, setScores] = useState({ player: 0, cigarette: 0 });
  const [status, setStatus] = useState("Your turn! Place your O");
  const [message, setMessage] = useState<{ title: string; text: string } | null>(null);
  const smokeContainerRef = useRef<HTMLDivElement>(null);

  const winningConditions = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
      [0, 4, 8], [2, 4, 6]           // diagonals
  ];

  type Player = 'O' | 'X' | '';

  const checkWin = (currentBoard: Player[], player: Player): boolean => {
    return winningConditions.some(condition => {
      return condition.every(index => currentBoard[index] === player);
    });
  };

  const isDraw = (currentBoard: Player[]): boolean => {
    return currentBoard.every(cell => cell !== '');
  };

  const handleCellClick = (index: number) => {
    if (board[index] !== '' || !gameActive || currentPlayer === 'X') {
      return;
    }

    const newBoard = [...board];
    newBoard[index] = 'O';
    setBoard(newBoard);
    
    if (checkWin(newBoard, 'O')) {
      endGame(false, 'O');
    } else if (isDraw(newBoard)) {
      endGame(true, null);
    } else {
      setCurrentPlayer('X');
      setStatus("Cigarette's turn...");
    }
  };
  
  const createSmokeEffect = () => {
    const container = smokeContainerRef.current;
    if (!container) return;
    
    container.innerHTML = '';
    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.className = 'smoke-particle';
        
        const left = Math.random() * 100;
        particle.style.left = `${left}%`;
        particle.style.bottom = '0';
        
        const size = 10 + Math.random() * 20;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        
        const duration = 2 + Math.random() * 3;
        const delay = Math.random() * 2;
        
        particle.style.animation = `smoke ${duration}s ease-out ${delay}s forwards`;
        
        container.appendChild(particle);
    }
  };

  const endGame = (isDrawResult: boolean, winner: Player | null) => {
    setGameActive(false);

    if (isDrawResult) {
      setMessage({ title: "It's a Draw!", text: "The battle continues... Try again!" });
    } else if (winner === 'O') {
      setScores(prev => ({ ...prev, player: prev.player + 1 }));
      setMessage({ title: "You Win!", text: "Well done! Show it who you really are!" });
    } else if (winner === 'X') {
      setScores(prev => ({ ...prev, cigarette: prev.cigarette + 1 }));
      setMessage({ title: "You Lose!", text: "The cigarette has killed you! Try again to prove that you can defeat it." });
      createSmokeEffect();
    }
  };

  const restartGame = () => {
    setBoard(Array(9).fill(''));
    setCurrentPlayer('O');
    setGameActive(true);
    setStatus("Your turn! Place your O");
    setMessage(null);
    if(smokeContainerRef.current) smokeContainerRef.current.innerHTML = '';
  };
  
  const closeMessage = () => {
      setMessage(null);
      restartGame();
  };

  useEffect(() => {
    if (currentPlayer === 'X' && gameActive) {
      const timeout = setTimeout(() => {
        let bestMove = -1;

        // 1. Find winning move for AI ('X')
        for (const condition of winningConditions) {
          const [a, b, c] = condition;
          if (board[a] === 'X' && board[b] === 'X' && board[c] === '') bestMove = c;
          else if (board[a] === 'X' && board[c] === 'X' && board[b] === '') bestMove = b;
          else if (board[b] === 'X' && board[c] === 'X' && board[a] === '') bestMove = a;
          if (bestMove !== -1) break;
        }

        // 2. Block player's winning move ('O')
        if (bestMove === -1) {
          for (const condition of winningConditions) {
            const [a, b, c] = condition;
            if (board[a] === 'O' && board[b] === 'O' && board[c] === '') bestMove = c;
            else if (board[a] === 'O' && board[c] === 'O' && board[b] === '') bestMove = b;
            else if (board[b] === 'O' && board[c] === 'O' && board[a] === '') bestMove = a;
            if (bestMove !== -1) break;
          }
        }
        
        // 3. Take a random available spot
        if (bestMove === -1) {
            const availableMoves = board.map((val, idx) => val === '' ? idx : -1).filter(idx => idx !== -1);
            if (availableMoves.length > 0) {
                bestMove = availableMoves[Math.floor(Math.random() * availableMoves.length)];
            }
        }

        if (bestMove !== -1) {
          const newBoard = [...board];
          newBoard[bestMove] = 'X';
          setBoard(newBoard);
          
          if (checkWin(newBoard, 'X')) {
            endGame(false, 'X');
          } else if (isDraw(newBoard)) {
            endGame(true, null);
          } else {
            setCurrentPlayer('O');
            setStatus("Your turn! Place your O");
          }
        }
      }, 800);

      return () => clearTimeout(timeout);
    }
  }, [currentPlayer, board, gameActive]);

  return (
    <>
      <style jsx global>{`
        .game-container-wrapper {
            background: linear-gradient(135deg, #1A1A2E 0%, #16213E 100%);
            color: #fff;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            text-align: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-y: auto;
        }
        .game-container-wrapper .title {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: #E94560;
            text-shadow: 0 0 10px rgba(233, 69, 96, 0.5);
        }
        .game-container-wrapper .subtitle {
            font-size: 1.2rem;
            margin-bottom: 30px;
            color: #533483;
        }
        .game-container-wrapper .scoreboard {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 320px;
            background: #0F3460;
            border-radius: 10px;
            padding: 15px 30px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .game-container-wrapper .player-score, .game-container-wrapper .cigarette-score {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .game-container-wrapper .player-icon, .game-container-wrapper .cigarette-icon {
            font-size: 2.5rem;
            margin-bottom: 5px;
        }
        .game-container-wrapper .player-icon { color: #E94560; }
        .game-container-wrapper .cigarette-icon { color: #E94560; }
        .game-container-wrapper .score { font-size: 1.8rem; font-weight: bold; }
        .game-container-wrapper .player-score .score { color: #fff; }
        .game-container-wrapper .cigarette-score .score { color: #fff; }
        .game-container-wrapper .vs {
            display: flex;
            align-items: center;
            font-size: 1.5rem;
            color: #E94560;
        }
        .game-container-wrapper .board-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }
        .game-container-wrapper .board {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-template-rows: repeat(3, 1fr);
            gap: 10px;
            width: 280px;
            height: 280px;
            margin-bottom: 20px;
            background-color: #0F3460;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }
        .game-container-wrapper .cell {
            background-color: #16213E;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .game-container-wrapper .cell:hover {
            background-color: #533483;
        }
        .game-container-wrapper .cell.x::before, .game-container-wrapper .cell.x::after {
            content: '';
            position: absolute;
            width: 80%;
            height: 10px;
            background-color: #E94560;
            border-radius: 5px;
        }
        .game-container-wrapper .cell.x::before { transform: rotate(45deg); }
        .game-container-wrapper .cell.x::after { transform: rotate(-45deg); }
        .game-container-wrapper .cell.o::before {
            content: '';
            position: absolute;
            width: 60%;
            height: 60%;
            border: 10px solid #4fc3f7;
            border-radius: 50%;
        }
        .game-container-wrapper .status {
            font-size: 1.3rem;
            margin-bottom: 20px;
            height: 30px;
            color: #533483;
        }
        .game-container-wrapper .controls {
            display: flex;
            gap: 15px;
            margin-top: 10px;
        }
        .game-container-wrapper button {
            background: #E94560;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(233, 69, 96, 0.3);
        }
        .game-container-wrapper button:hover {
            background: #ff6b81;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(233, 69, 96, 0.4);
        }
        .game-container-wrapper .message-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
        .game-container-wrapper .message-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 1px solid #E94560;
        }
        .game-container-wrapper .message-content h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #E94560;
        }
        .game-container-wrapper .message-content p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            line-height: 1.5;
        }
        .game-container-wrapper .message-content button {
            background: #533483;
            box-shadow: 0 4px 10px rgba(83, 52, 131, 0.3);
        }
        .game-container-wrapper .message-content button:hover {
            background: #6f42c1;
            box-shadow: 0 6px 15px rgba(83, 52, 131, 0.4);
        }
        .game-container-wrapper .smoke {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: -1;
            overflow: hidden;
        }
        .game-container-wrapper .smoke-particle {
            position: absolute;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            opacity: 0;
        }
        @keyframes smoke {
            0% { transform: translateY(0) scale(1); opacity: 0.7; }
            100% { transform: translateY(-100px) scale(2); opacity: 0; }
        }

        @media (max-width: 600px) {
            .game-container-wrapper .title { font-size: 2rem; }
            .game-container-wrapper .scoreboard { padding: 10px 15px; }
            .game-container-wrapper .player-icon, .game-container-wrapper .cigarette-icon { font-size: 2rem; }
            .game-container-wrapper .board { width: 280px; height: 280px; }
            .game-container-wrapper .cell { font-size: 2.5rem; }
        }
      `}</style>
      <div className="game-container-wrapper">
        <div className="container">
            <h1 className="title">TIC TAC TOE</h1>
            <p className="subtitle">Player vs Cigarette</p>
            
            <div className="scoreboard">
                <div className="player-score">
                    <div className="player-icon">👤</div>
                    <div className="score">{scores.player}</div>
                </div>
                
                <div className="vs">VS</div>
                
                <div className="cigarette-score">
                    <div className="cigarette-icon">🚬</div>
                    <div className="score">{scores.cigarette}</div>
                </div>
            </div>
            
            <div className="board-container">
                <div className="status">{status}</div>
                <div className="board">
                  {board.map((value, index) => (
                    <div
                      key={index}
                      className={cn("cell", value ? value.toLowerCase() : "")}
                      onClick={() => handleCellClick(index)}
                    />
                  ))}
                </div>
            </div>
        </div>
        
        {message && (
          <div className={cn("message-overlay", message ? "show" : "")}>
              <div className="message-content">
                  <h2>{message.title}</h2>
                  <p>{message.text}</p>
                  <button onClick={closeMessage}>Play Again</button>
              </div>
          </div>
        )}
        
        <div ref={smokeContainerRef} className="smoke"></div>
        <DialogClose asChild>
            <button style={{
                width: '80%',
                maxWidth: '280px',
                background: '#e94560',
                color: 'white',
                border: 'none',
                padding: '12px 25px',
                borderRadius: '30px',
                fontSize: '1rem',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 4px 10px rgba(233, 69, 96, 0.3)',
                marginTop: 'auto',
                marginBottom: '20px'
            }}>Exit Game</button>
        </DialogClose>
      </div>
    </>
  );
};

export default TicTacToeGame;
