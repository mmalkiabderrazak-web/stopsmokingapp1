
'use client';

const lungTestHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lung Health Test</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        body {
            background: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 10px;
        }
        .container {
            width: 100%;
            max-width: 340px;
            height: 600px;
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            overflow: auto;
            padding: 15px;
            display: flex;
            flex-direction: column;
        }
        .header {
            text-align: center;
            margin-bottom: 15px;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 20px;
            margin-bottom: 5px;
        }
        .header p {
            color: #7f8c8d;
            font-size: 12px;
        }
        .test-section {
            background: #f8f9ff;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            text-align: center;
            border: 1px dashed #6C63FF;
        }
        .breath-button {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            background: linear-gradient(135deg, #6C63FF 0%, #4A43C9 100%);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 8px 20px rgba(108, 99, 255, 0.3);
            border: none;
            outline: none;
            font-weight: 600;
            font-size: 14px;
        }
        .breath-button:active, .breath-button.holding {
            transform: scale(0.95);
            box-shadow: 0 4px 12px rgba(108, 99, 255, 0.5);
        }
        .timer {
            font-size: 32px;
            font-weight: 700;
            color: #2c3e50;
            margin: 10px 0;
            font-variant-numeric: tabular-nums;
        }
        .instructions {
            color: #7f8c8d;
            font-size: 12px;
            margin-bottom: 10px;
            line-height: 1.4;
        }
        .progress-bar {
            height: 6px;
            background: #e6e9ff;
            border-radius: 3px;
            margin: 10px 0;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #6C63FF, #4A43C9);
            border-radius: 3px;
            width: 0%;
            transition: width 0.5s ease;
        }
        .results-section {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            display: none;
        }
        .score-display {
            text-align: center;
            margin-bottom: 15px;
        }
        .score-value {
            font-size: 36px;
            font-weight: 700;
            color: #6C63FF;
            margin-bottom: 3px;
        }
        .score-label {
            font-size: 14px;
            color: #7f8c8d;
        }
        .ai-feedback {
            background: #f0f3ff;
            border-radius: 10px;
            padding: 12px;
            margin-bottom: 12px;
        }
        .ai-feedback h3 {
            color: #6C63FF;
            margin-bottom: 8px;
            font-size: 15px;
        }
        .feedback-text {
            color: #5a5a7a;
            line-height: 1.4;
            font-size: 12px;
        }
        .health-tip {
            background: #fff8f0;
            border: 1px solid #ffcc99;
            border-radius: 8px;
            padding: 10px;
        }
        .health-tip h4 {
            color: #ff9933;
            margin-bottom: 4px;
            font-size: 13px;
        }
        .health-tip p {
            color: #5a5a7a;
            font-size: 11px;
            line-height: 1.4;
        }
        .chart-section {
            margin-top: 15px;
        }
        .chart-container {
            height: 150px;
            position: relative;
        }
        .history-section {
            background: white;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }
        .history-section h3 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 15px;
        }
        .history-list {
            max-height: 120px;
            overflow-y: auto;
        }
        .history-item {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 12px;
        }
        .history-date {
            color: #7f8c8d;
        }
        .history-score {
            color: #6C63FF;
            font-weight: 600;
        }
        .api-status {
            text-align: center;
            font-size: 10px;
            color: #a8a8c7;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Lung Health Test</h1>
            <p>Measure your breath-holding capacity</p>
        </div>
        <div class="test-section">
            <div class="instructions">
                <p>Take a deep breath, then press and hold the button for as long as you can.</p>
            </div>
            <button class="breath-button" id="breathButton">
                Hold Breath
            </button>
            <div class="timer" id="timer">00.00s</div>
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill"></div>
            </div>
        </div>
        <div class="results-section" id="resultsSection">
            <div class="score-display">
                <div class="score-value" id="scoreValue">0%</div>
                <div class="score-label" id="scoreLabel">Lung Capacity</div>
            </div>
            <div class="ai-feedback">
                <h3>AI Analysis</h3>
                <div class="feedback-text" id="feedbackText">
                    Analyzing your results...
                </div>
            </div>
            <div class="health-tip">
                <h4>Health Tip</h4>
                <p id="healthTip">Regular breathing exercises improve lung capacity.</p>
            </div>
            <div class="chart-section">
                <h3>Progress</h3>
                <div class="chart-container">
                    <canvas id="progressChart"></canvas>
                </div>
            </div>
        </div>
        <div class="history-section">
            <h3>History</h3>
            <div class="history-list" id="historyList">
                <!-- History items will be added here -->
            </div>
        </div>
        <div class="api-status" id="apiStatus">AI Analysis Ready</div>
    </div>
    <script>
        const API_KEY = "${process.env.NEXT_PUBLIC_OPENROUTER_API_KEY}";
        const API_URL = "https://openrouter.ai/api/v1/chat/completions";
        const breathButton = document.getElementById('breathButton');
        const timerDisplay = document.getElementById('timer');
        const progressFill = document.getElementById('progressFill');
        const resultsSection = document.getElementById('resultsSection');
        const scoreValue = document.getElementById('scoreValue');
        const scoreLabel = document.getElementById('scoreLabel');
        const feedbackText = document.getElementById('feedbackText');
        const healthTip = document.getElementById('healthTip');
        const historyList = document.getElementById('historyList');
        const apiStatus = document.getElementById('apiStatus');
        let startTime = 0;
        let timerInterval = null;
        let isTesting = false;
        let holdTime = 0;
        let testHistory = JSON.parse(localStorage.getItem('lungTestHistory')) || [];
        let progressChart = null;
        
        function startTest() {
            if (isTesting) return;
            isTesting = true;
            breathButton.classList.add('holding');
            startTime = Date.now();
            timerInterval = setInterval(updateTimer, 10);
            progressFill.style.width = '0%';
        }
        
        function updateTimer() {
            const currentTime = Date.now();
            holdTime = (currentTime - startTime) / 1000;
            timerDisplay.textContent = holdTime.toFixed(2) + 's';
            const progressPercent = Math.min((holdTime / 120) * 100, 100);
            progressFill.style.width = progressPercent + '%';
            if (holdTime > 60) {
                progressFill.style.background = 'linear-gradient(90deg, #4CAF50, #2E7D32)';
            } else if (holdTime > 30) {
                progressFill.style.background = 'linear-gradient(90deg, #FF9800, #F57C00)';
            } else {
                progressFill.style.background = 'linear-gradient(90deg, #6C63FF, #4A43C9)';
            }
        }

        function endTest() {
            if (!isTesting) return;
            isTesting = false;
            breathButton.classList.remove('holding');
            clearInterval(timerInterval);
            const score = Math.min(Math.round((holdTime / 60) * 100), 100);
            showResults(score, holdTime);
            saveToHistory(score, holdTime);
            updateChart();
        }

        function showResults(score, time) {
            resultsSection.style.display = 'block';
            scoreValue.textContent = score + '%';
            if (score >= 80) {
                scoreLabel.textContent = 'Excellent';
                scoreValue.style.color = '#4CAF50';
            } else if (score >= 60) {
                scoreLabel.textContent = 'Good';
                scoreValue.style.color = '#FF9800';
            } else if (score >= 40) {
                scoreLabel.textContent = 'Average';
                scoreValue.style.color = '#6C63FF';
            } else {
                scoreLabel.textContent = 'Needs Improvement';
                scoreValue.style.color = '#F44336';
            }
            resultsSection.scrollIntoView({ behavior: 'smooth' });
            getAIFeedback(score, time);
        }

        async function getAIFeedback(score, time) {
            apiStatus.textContent = "AI Analyzing...";
            apiStatus.style.color = "#FF9800";
            try {
                const response = await fetch(API_URL, {
                    method: "POST",
                    headers: {
                        "Authorization": \`Bearer \${API_KEY}\`,
                        "Content-Type": "application/json",
                        "HTTP-Referer": window.location.origin,
                        "X-Title": "Lung Health Test"
                    },
                    body: JSON.stringify({
                        "model": "openai/gpt-3.5-turbo",
                        "messages": [
                            {
                                "role": "system",
                                "content": \`You are a lung health specialist AI. The user just completed a breath-holding test.
                                
                                Test Results:
                                - Breath-hold time: \${time.toFixed(2)} seconds
                                - Lung capacity score: \${score}%
                                
                                Your task:
                                1. Provide a brief analysis of their lung health based on the results
                                2. Give motivational feedback (encouraging but honest)
                                3. Offer 1-2 specific tips to improve lung health
                                4. Keep response under 120 words
                                
                                Important: Be empathetic and supportive. If the score is low, focus on improvement potential.\`
                            },
                            {
                                "role": "user",
                                "content": "Please analyze my lung health test results."
                            }
                        ],
                        "max_tokens": 200,
                        "temperature": 0.7
                    })
                });

                if (!response.ok) throw new Error(\`API request failed: \${response.status}\`);
                
                const data = await response.json();
                if (data.choices && data.choices[0] && data.choices[0].message) {
                    const aiResponse = data.choices[0].message.content;
                    feedbackText.textContent = aiResponse;
                    generateHealthTip(score);
                    apiStatus.textContent = "AI Analysis Complete";
                    apiStatus.style.color = "#4CAF50";
                } else {
                    throw new Error('Invalid response format from API');
                }
            } catch (error) {
                console.error('API Error:', error);
                apiStatus.textContent = "AI Connection Issue";
                apiStatus.style.color = "#F44336";
                feedbackText.textContent = getFallbackFeedback(score, time);
                generateHealthTip(score);
            }
        }

        function generateHealthTip(score) {
            let tip = "";
            if (score >= 80) tip = "Maintain lung health with regular cardio and deep breathing.";
            else if (score >= 60) tip = "Try diaphragmatic breathing daily to improve capacity.";
            else if (score >= 40) tip = "Brisk walking or swimming strengthens respiratory muscles.";
            else tip = "Practice pursed-lip breathing to improve lung function.";
            healthTip.textContent = tip;
        }

        function getFallbackFeedback(score, time) {
            if (score >= 80) return \`Excellent! \${time.toFixed(1)} seconds indicates strong lung capacity. Keep up regular exercise to maintain this level.\`;
            if (score >= 60) return \`Good result! With consistent breathing exercises, you can further improve your lung capacity.\`;
            if (score >= 40) return \`Your breath-hold time is average. Regular practice can significantly improve lung function.\`;
            return \`Your lung capacity has room for improvement. With consistent practice, you can strengthen your respiratory system.\`;
        }

        function saveToHistory(score, time) {
            const testResult = {
                date: new Date().toLocaleDateString(),
                time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                score: score,
                holdTime: time
            };
            testHistory.unshift(testResult);
            if (testHistory.length > 8) testHistory = testHistory.slice(0, 8);
            localStorage.setItem('lungTestHistory', JSON.stringify(testHistory));
            updateHistoryDisplay();
        }

        function updateHistoryDisplay() {
            historyList.innerHTML = '';
            testHistory.forEach(result => {
                const historyItem = document.createElement('div');
                historyItem.className = 'history-item';
                historyItem.innerHTML = \`<div class="history-date">\${result.date}</div><div class="history-score">\${result.score}%</div>\`;
                historyList.appendChild(historyItem);
            });
        }

        function initializeChart() {
            const ctx = document.getElementById('progressChart').getContext('2d');
            const dates = testHistory.map(result => result.date).reverse();
            const scores = testHistory.map(result => result.score).reverse();
            progressChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dates,
                    datasets: [{
                        label: 'Score',
                        data: scores,
                        borderColor: '#6C63FF',
                        backgroundColor: 'rgba(108, 99, 255, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#6C63FF',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: true, max: 100, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 9 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 9 } } }
                    },
                    plugins: { legend: { display: false } }
                }
            });
        }

        function updateChart() {
            const dates = testHistory.map(result => result.date).reverse();
            const scores = testHistory.map(result => result.score).reverse();
            progressChart.data.labels = dates;
            progressChart.data.datasets[0].data = scores;
            progressChart.update();
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            initializeChart();
            updateHistoryDisplay();
            breathButton.addEventListener('mousedown', startTest);
            breathButton.addEventListener('touchstart', startTest, { passive: true });
            document.addEventListener('mouseup', endTest);
            document.addEventListener('touchend', endTest);
        });

    </script>
</body>
</html>
`;

const LungHealthTest = () => {
  return (
    <iframe
      srcDoc={lungTestHtml}
      style={{ width: '100%', height: '100%', border: 'none' }}
      title="Lung Health Test"
    />
  );
};

export default LungHealthTest;
