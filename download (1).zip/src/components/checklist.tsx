'use client';

import { useApp } from '@/contexts/app-provider';
import type { DayPlan } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ClipboardList } from 'lucide-react';
import { Progress } from './ui/progress';
import { useEffect, useState } from 'react';
import { Skeleton } from './ui/skeleton';

interface ChecklistProps {
  day: number;
  items: DayPlan['checklist'];
}

export default function Checklist({ day, items }: ChecklistProps) {
  const { isChecklistCompleted, updateChecklist } = useApp();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const completedCount = items.filter(item => isChecklistCompleted(day, item.id)).length;
  const progress = items.length > 0 ? (completedCount / items.length) * 100 : 0;

  return (
    <Card className="animate-fade-in-up" style={{ animationDelay: '400ms'}}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ClipboardList className="h-5 w-5 text-primary" />
          Today's Checklist
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {!isClient ? (
            <>
              <div className="flex items-center space-x-3">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-4/5" />
              </div>
              <div className="flex items-center space-x-3">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-3/5" />
              </div>
            </>
          ) : (
            items.map(item => (
              <div key={item.id} className="flex items-center space-x-3 transition-colors rounded-md p-2 hover:bg-muted/50">
                <Checkbox
                  id={item.id}
                  checked={isChecklistCompleted(day, item.id)}
                  onCheckedChange={(checked) => {
                    updateChecklist(day, item.id, !!checked);
                  }}
                />
                <Label
                  htmlFor={item.id}
                  className={`flex-1 text-sm font-medium leading-none cursor-pointer ${
                    isChecklistCompleted(day, item.id) ? 'text-muted-foreground line-through' : 'text-foreground'
                  }`}
                >
                  {item.label}
                </Label>
              </div>
            ))
          )}
        </div>
        <div className="mt-4">
          {isClient ? (
            <div className="flex items-center gap-2">
              <Progress value={progress} className="h-2" />
              <span className="text-xs font-semibold text-muted-foreground">{Math.round(progress)}%</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
               <Skeleton className="h-2 w-full" />
               <Skeleton className="h-4 w-8" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
