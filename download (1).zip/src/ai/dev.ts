
import { config } from 'dotenv';
config();
