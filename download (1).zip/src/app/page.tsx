'use client';
import { useApp } from '@/contexts/app-provider';
import OnboardingForm from '@/components/onboarding-form';
import DashboardGrid from '@/components/dashboard-grid';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { calculateTotalSavings } from '@/lib/utils';
import { Leaf, Calendar, DollarSign, TrendingUp, User, RotateCcw } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { daysData } from '@/lib/days-data';
import { Button } from '@/components/ui/button';
import RealityCheck from '@/components/reality-check';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import TicTacToeGame from '@/components/tic-tac-toe-game';
import HealthCoach from '@/components/health-coach';
import LungHealthTest from '@/components/lung-health-test';


export default function Home() {
  const { user, isLoading, isChecklistCompleted, resetJourney } = useApp();

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center" style={{ backgroundColor: 'var(--main-bg)'}}>
        <div className="flex flex-col items-center gap-4">
          <Leaf className="h-12 w-12 animate-spin text-primary" />
          <p className="text-primary/80">Loading your journey...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <OnboardingForm />;
  }
  
  const getChecklistProgressForDay = (dayNumber: number): number => {
    const dayData = daysData.find(d => d.day === dayNumber);
    if (!dayData || dayData.checklist.length === 0) {
      return 100;
    }
    const completedCount = dayData.checklist.filter(item => isChecklistCompleted(dayNumber, item.id)).length;
    return (completedCount / dayData.checklist.length) * 100;
  };

  const findLastCompletedDay = () => {
    let lastCompletedDay = 0;
    for (let i = 1; i <= 21; i++) {
        if (getChecklistProgressForDay(i) === 100) {
            lastCompletedDay = i;
        } else {
            break;
        }
    }
    return lastCompletedDay;
  };
  
  const lastCompletedDay = findLastCompletedDay();
  const currentDay = lastCompletedDay + 1;

  const totalSavings = calculateTotalSavings(user.cigarettesPerDay, user.pricePerPack, lastCompletedDay);
  
  const getOverallProgress = () => {
    const totalChecklistItemsInProgram = daysData.reduce((sum, day) => sum + day.checklist.length, 0);
    if (totalChecklistItemsInProgram === 0) return 0;

    const completedChecklistItems = daysData.reduce((sum, day) => {
        const completedInDay = day.checklist.filter(item => isChecklistCompleted(day.day, item.id)).length;
        return sum + completedInDay;
    }, 0);
    
    return (completedChecklistItems / totalChecklistItemsInProgram) * 100;
  }
  
  const overallProgress = getOverallProgress();
  const displayDay = currentDay > 21 ? 21 : currentDay;
  const daysSmokeFree = lastCompletedDay > 0 ? lastCompletedDay : 0;


  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--main-bg)'}}>
      <main className="container mx-auto p-4 md:p-6 text-text-secondary">
        <header className="mb-6 flex flex-col items-center text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-text-primary">Hello, {user.name}! 👋</h1>
            <p className="text-base text-text-secondary mt-1">Your Smoke-Free Journey</p>
        </header>

        <div className="text-right mb-4">
          <Button variant="outline" size="sm" onClick={resetJourney}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset Progress
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="bg-primary border-0 text-white rounded-2xl shadow-lg">
            <CardContent className="p-4 flex flex-col items-start justify-center">
              <Calendar className="w-6 h-6 mb-2 opacity-80" />
              <p className="text-2xl font-bold">{daysSmokeFree}</p>
              <p className="text-sm opacity-90">Days Smoke-Free</p>
            </CardContent>
          </Card>
          <Card className="bg-accent border-0 text-white rounded-2xl shadow-lg">
            <CardContent className="p-4 flex flex-col items-start justify-center">
              <DollarSign className="w-6 h-6 mb-2 opacity-80" />
              <p className="text-2xl font-bold">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalSavings)}
              </p>
              <p className="text-sm opacity-90">Money Saved</p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8 bg-card-bg text-card-foreground shadow-lg rounded-2xl">
          <CardContent className="p-4">
             <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-primary"/>
                <h3 className="font-semibold text-base text-text-primary">Your Progress</h3>
             </div>
             <Progress value={overallProgress} />
             <p className="text-xs text-muted-foreground mt-2 text-center">
               Day {displayDay} of 21・{Math.round(overallProgress)}% Complete
             </p>
          </CardContent>
        </Card>
        
        <div className="mb-8">
           <div className="flex items-center gap-2 mb-4">
            <User className="text-text-primary" />
            <h2 className="text-xl font-bold text-text-primary">21-Day Journey</h2>
           </div>
           <DashboardGrid />
        </div>
        
        <div className="my-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Dialog>
                    <DialogTrigger asChild>
                        <Card className="group cursor-pointer hover:bg-primary/5 transition-all duration-300">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <span className="text-3xl transition-transform group-hover:scale-110">🎮</span>
                                    <div>
                                        <h3 className="text-lg font-semibold text-text-primary">Game</h3>
                                        <p className="text-sm font-normal text-text-secondary">Play a game to beat cravings</p>
                                    </div>
                                </CardTitle>
                            </CardHeader>
                        </Card>
                    </DialogTrigger>
                    <DialogContent className="p-0 max-w-[360px] w-full h-[640px] flex flex-col">
                        <DialogHeader className="sr-only">
                            <DialogTitle>Tic Tac Toe Game</DialogTitle>
                            <DialogDescription>
                                Play a game of Tic Tac Toe against a cigarette to beat cravings.
                            </DialogDescription>
                        </DialogHeader>
                        <TicTacToeGame />
                    </DialogContent>
                </Dialog>

                <Dialog>
                    <DialogTrigger asChild>
                         <Card className="group cursor-pointer hover:bg-primary/5 transition-all duration-300">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <span className="text-3xl transition-transform group-hover:scale-110">👨‍⚕️</span>
                                    <div>
                                        <h3 className="text-lg font-semibold text-text-primary">Doctor</h3>
                                        <p className="text-sm font-normal text-text-secondary">Chat with AI Health Coach</p>
                                    </div>
                                </CardTitle>
                            </CardHeader>
                        </Card>
                    </DialogTrigger>
                    <DialogContent className="p-0 max-w-[360px] w-full h-[640px] flex flex-col items-center justify-center">
                        <DialogHeader className="sr-only">
                            <DialogTitle>AI Health Coach</DialogTitle>
                            <DialogDescription>
                                Chat with an AI Health Coach to get medical advice and support for quitting smoking.
                            </DialogDescription>
                        </DialogHeader>
                        <HealthCoach />
                    </DialogContent>
                </Dialog>

                <Dialog>
                    <DialogTrigger asChild>
                         <Card className="group cursor-pointer hover:bg-primary/5 transition-all duration-300">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <div>
                                        <h3 className="text-lg font-semibold text-text-primary">Test Your Lungs</h3>
                                        <p className="text-sm font-normal text-text-secondary">Take a breath-holding test</p>
                                    </div>
                                </CardTitle>
                            </CardHeader>
                        </Card>
                    </DialogTrigger>
                    <DialogContent className="p-0 max-w-[360px] w-full h-[640px] flex flex-col">
                        <DialogHeader className="sr-only">
                            <DialogTitle>Lung Health Test</DialogTitle>
                            <DialogDescription>
                                Test your lung capacity with a breath-holding game.
                            </DialogDescription>
                        </DialogHeader>
                        <LungHealthTest />
                    </DialogContent>
                </Dialog>
                
            </div>
        </div>

        <RealityCheck />
      </main>
    </div>
  );
}
