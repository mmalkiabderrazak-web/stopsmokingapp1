import DayDetails from '@/components/day-details';
import { daysData } from '@/lib/days-data';
import { notFound } from 'next/navigation';
import type { Metadata, ResolvingMetadata } from 'next'

type Props = {
  params: { day: string }
}
 
export async function generateMetadata(
  { params }: Props,
  parent: ResolvingMetadata
): Promise<Metadata> {
  const dayNumber = parseInt(params.day, 10);
  const dayData = daysData.find(d => d.day === dayNumber);
 
  return {
    title: `Day ${dayData?.day}: ${dayData?.title} | BreatheEasy`,
    description: dayData?.theme,
  }
}

export default function DayPage({ params }: { params: { day: string } }) {
  const dayNumber = parseInt(params.day, 10);
  const dayData = daysData.find(d => d.day === dayNumber);

  if (!dayData || isNaN(dayNumber) || dayNumber < 1 || dayNumber > 21) {
    notFound();
  }

  return <DayDetails dayData={dayData} />;
}

export async function generateStaticParams() {
  return daysData.map(day => ({
    day: day.day.toString(),
  }));
}
