'use client';

import { createContext, useContext, useState, ReactNode, useEffect, useCallback } from 'react';
import useLocalStorage from '@/hooks/use-local-storage';
import type { UserProfile } from '@/lib/types';

interface AppContextType {
  user: UserProfile | null;
  setUser: (user: UserProfile | null) => void;
  isLoading: boolean;
  completedChecklists: Record<string, string[]>;
  updateChecklist: (day: number, checklistId: string, isCompleted: boolean) => void;
  isChecklistCompleted: (day: number, checklistId: string) => boolean;
  resetJourney: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useLocalStorage<UserProfile | null>('breatheasy-user', null);
  const [isLoading, setIsLoading] = useState(true);
  const [completedChecklists, setCompletedChecklists] = useLocalStorage<Record<string, string[]>>('breatheasy-checklists', {});

  useEffect(() => {
    setIsLoading(false);
  }, []);

  const updateChecklist = (day: number, checklistId: string, isCompleted: boolean) => {
    const dayKey = `day-${day}`;
    setCompletedChecklists(prev => {
      const dayChecklist = prev[dayKey] ? [...prev[dayKey]] : [];
      if (isCompleted) {
        if (!dayChecklist.includes(checklistId)) {
          dayChecklist.push(checklistId);
        }
      } else {
        const index = dayChecklist.indexOf(checklistId);
        if (index > -1) {
          dayChecklist.splice(index, 1);
        }
      }
      return { ...prev, [dayKey]: dayChecklist };
    });
  };

  const isChecklistCompleted = (day: number, checklistId: string): boolean => {
    const dayKey = `day-${day}`;
    return completedChecklists[dayKey]?.includes(checklistId) ?? false;
  };
  
  const resetJourney = useCallback(() => {
    setUser(null);
    setCompletedChecklists({});
  }, [setUser, setCompletedChecklists]);

  return (
    <AppContext.Provider value={{ user, setUser, isLoading, completedChecklists, updateChecklist, isChecklistCompleted, resetJourney }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
