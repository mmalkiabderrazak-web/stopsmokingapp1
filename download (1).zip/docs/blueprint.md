# **App Name**: BreatheEasy: 21 Days to Freedom

## Core Features:

- User Profile Setup: Collects user data (name, age, smoking habits, cost per pack) to personalize the experience and calculate savings.
- 21-Day Schedule Display: Presents a clear, day-by-day schedule of activities, remedies, and mindset tasks.
- Daily Content Delivery: Displays specific content for each day (remedy, exercise, guidance, craving buster) with images.
- Financial Savings Tracker: Calculates and displays the amount of money saved each day and cumulatively.
- Breath-Holding Game: Interactive game where the user presses and holds a button while holding their breath, visualizing lung inflation.  Provides time elapsed and lung status (good, improving).
- Personalized Feedback: Uses the output from the 'breath-holding game' to offer personalized feedback about the user's lung health based on the session.
- Daily Checklist: Provides a checklist of daily tasks for the user to mark as complete, reinforcing adherence to the plan.

## Style Guidelines:

- Primary color: Deep teal (#468499) to evoke a sense of calm, health, and nature. It is not overpowering but professional and supportive.
- Background color: Very light, desaturated teal (#F0F8FF) to provide a soft, calming backdrop without distracting from the content.
- Accent color: Muted gold (#B8860B) to highlight important elements like savings, checklist items, and congratulatory messages.
- Body and Headline font: 'PT Sans' (sans-serif) to make all of the instructions clear and readable.
- Use clean, modern icons to represent remedies, exercises, and checklist items.  The lung icon in the game should be visually engaging, with subtle animations during the breath-holding activity.
- Employ a clean, card-based layout to organize daily content.  Use white space effectively to avoid overwhelming the user.  The 21-day schedule should be prominently displayed for easy navigation.
- Subtle transitions and animations to provide feedback, reveal content, and enhance the game experience.  For example, the lung inflating during the breath-holding game or a satisfying checkmark animation upon completing a checklist item.